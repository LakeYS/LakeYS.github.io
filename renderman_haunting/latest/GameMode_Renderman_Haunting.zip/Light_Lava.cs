// Basic Lights
datablock fxLightData(RedBrightLight)
{
	uiName = "Lava Light";

	LightOn = true;
	radius = 20;
	brightness = 15;
	color = "1 0 0 1";

	FlareOn			= false;

	AnimColor		= false;
	AnimBrightness	= false;
	AnimOffsets		= false;
	AnimRotation	= false;
	LinkFlare		= true;
	LinkFlareSize	= false;
	MinColor		= "0 0 0";
	MaxColor		= "1 0 0 1";
	MinBrightness	= 0.0;
	MaxBrightness	= 1.0;
	MinRadius		= 0.1;
	MaxRadius		= 20;
	StartOffset		= "-5 0 0";
	EndOffset		= "5 0 0";
	MinRotation		= 0;
	MaxRotation		= 359;

	SingleColorKeys	= true;
	RedKeys			= "AZA";
	GreenKeys		= "AZA";
	BlueKeys		= "AZA";
	
	BrightnessKeys	= "AZA";
	RadiusKeys		= "AZA";
	OffsetKeys		= "AZA";
	RotationKeys	= "AZA";

	ColorTime		= 5.0;
	BrightnessTime	= 5.0;
	RadiusTime		= 5.0;
	OffsetTime		= 5.0;
	RotationTime	= 5.0;

	LerpColor		= true;
	LerpBrightness	= true;
	LerpRadius		= true;
	LerpOffset		= true;
	LerpRotation	= true;
};
