//custom audio
datablock AudioProfile(CoinCollect1)
{
	filename = "./Audio/Coin1.wav";
	description = AudioClosest3d;
	preload = false;
};

datablock AudioProfile(CoinCollect2)
{
	filename = "./Audio/Coin2.wav";
	description = AudioClosest3d;
	preload = false;
};

datablock AudioProfile(CoinCollect3)
{
	filename = "./Audio/Coin3.wav";
	description = AudioClosest3d;
	preload = false;
};

datablock AudioProfile(PageCollect1)
{
	filename = "./Audio/Page1.wav";
	description = AudioClosest3d;
	preload = false;
};

datablock AudioProfile(PageCollect2)
{
	filename = "./Audio/Page2.wav";
	description = AudioClosest3d;
	preload = false;
};

datablock AudioProfile(PageCollect3)
{
	filename = "./Audio/Page3.wav";
	description = AudioClosest3d;
	preload = false;
};

datablock AudioProfile(PageCollect4)
{
	filename = "./Audio/Page4.wav";
	description = AudioClosest3d;
	preload = false;
};

datablock AudioProfile(PageCollect5)
{
	filename = "./Audio/Page5.wav";
	description = AudioClosest3d;
	preload = false;
};

datablock AudioProfile(SkullCollect1)
{
	filename = "./Audio/Knock1.wav";
	description = AudioClosest3d;
	preload = false;
};

datablock AudioProfile(SkullCollect2)
{
	filename = "./Audio/Knock2.wav";
	description = AudioClosest3d;
	preload = false;
};

datablock AudioProfile(SkullCollect3)
{
	filename = "./Audio/Knock3.wav";
	description = AudioClosest3d;
	preload = false;
};

datablock AudioProfile(SkullCollect4)
{
	filename = "./Audio/Knock4.wav";
	description = AudioClosest3d;
	preload = false;
};

datablock AudioProfile(SkullCollect5)
{
	filename = "./Audio/Knock5.wav";
	description = AudioClosest3d;
	preload = false;
};
