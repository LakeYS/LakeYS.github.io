exec("./bricks.cs");
exec("./Light_Lava.cs"); // Custom light for the map
exec("./sound_renderYS.cs"); // Custom sounds for the map

// # Renderman Versions # //
// Load them all!

// Support_Render
if(isFile("Add-Ons/Support_Render/server.cs"))
  exec("Add-Ons/Support_Render/server.cs");

// Support_Rendermen
if(isFile("Add-Ons/Support_Rendermen/server.cs"))
  exec("Add-Ons/Support_Rendermen/server.cs");

// Support_Rendermen_CellPhones
if(isFile("Add-Ons/Support_Rendermen_CellPhones/server.cs"))
  exec("Add-Ons/Support_Rendermen_CellPhones/server.cs");

// Support_Rendermen_Modded
if(isFile("Add-Ons/Support_Rendermen_Modded/server.cs"))
  exec("Add-Ons/Support_Rendermen_Modded/server.cs");

// Support_RendermenFixed
if(isFile("Add-Ons/Support_RendermenFixed/server.cs"))
  exec("Add-Ons/Support_RendermenFixed/server.cs");

// Support_RendermenFixed
if(isFile("Add-Ons/Support_RendermenFixed/server.cs"))
  exec("Add-Ons/Support_RendermenFixed/server.cs");

// Script_Prepper
if(isFile("Add-Ons/Script_Prepper/server.cs"))
  exec("Add-Ons/Script_Prepper/server.cs");

// Support_Prepper
if(isFile("Add-Ons/Support_Prepper/server.cs"))
  exec("Add-Ons/Support_Prepper/server.cs");
