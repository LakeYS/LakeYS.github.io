// RH Wall Bricks
datablock fxDTSBrickData (brick1x64x60Data)
{
	brickFile = "Add-Ons/Brick_RH/1x64x60.blb";
	category = "RH";
	subCategory = "Wall";
	uiName = "1x64x60";
};

datablock fxDTSBrickData (brick1x48x60Data)
{
	brickFile = "Add-Ons/Brick_RH/1x48x60.blb";
	category = "RH";
	subCategory = "Wall";
	uiName = "1x48x60";
};

datablock fxDTSBrickData (brick1x64x30Data)
{
	brickFile = "Add-Ons/Brick_RH/1x64x30.blb";
	category = "RH";
	subCategory = "Wall";
	uiName = "1x64x30";
};

datablock fxDTSBrickData (brick1x55x30Data)
{
	brickFile = "Add-Ons/Brick_RH/1x55x30.blb";
	category = "RH";
	subCategory = "Wall";
	uiName = "1x55x30";
};

datablock fxDTSBrickData (brick1x38x30Data)
{
	brickFile = "Add-Ons/Brick_RH/1x38x30.blb";
	category = "RH";
	subCategory = "Wall";
	uiName = "1x38x30";
};

// Sparky Pack Bricks
datablock fxDTSBrickData (brick8x32Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/8x32.blb";
	category = "Bricks";
	subCategory = "8x";
	uiName = "8x32";
};

datablock fxDTSBrickData (brick8x48Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/8x48.blb";
	category = "Bricks";
	subCategory = "8x";
	uiName = "8x48";
};

datablock fxDTSBrickData (brick8x64Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/8x64.blb";
	category = "Bricks";
	subCategory = "8x";
	uiName = "8x64";
};

datablock fxDTSBrickData (brick16x16Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/16x32.blb";
	category = "baseplates";
	subCategory = "plain";
	uiName = "16x16";
};

datablock fxDTSBrickData (brick16x16Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/16x32.blb";
	category = "baseplates";
	subCategory = "plain";
	uiName = "16x32";
};

datablock fxDTSBrickData (brick16x48Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/16x48.blb";
	category = "baseplates";
	subCategory = "plain";
	uiName = "16x48";
};

datablock fxDTSBrickData (brick16x64Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/16x64.blb";
	category = "baseplates";
	subCategory = "plain";
	uiName = "16x64";
};

datablock fxDTSBrickData (brick32x32Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/32x32.blb";
	category = "baseplates";
	subCategory = "plain";
	uiName = "32x32";
};

datablock fxDTSBrickData (brick32x48Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/32x48.blb";
	category = "baseplates";
	subCategory = "plain";
	uiName = "32x48";
};

datablock fxDTSBrickData (brick32x64Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/32x64.blb";
	category = "baseplates";
	subCategory = "plain";
	uiName = "32x64";
};

datablock fxDTSBrickData (brick48x48Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/48x48.blb";
	category = "baseplates";
	subCategory = "plain";
	uiName = "48x48";
};

datablock fxDTSBrickData (brick48x64Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/48x64.blb";
	category = "baseplates";
	subCategory = "plain";
	uiName = "48x64";
};

datablock fxDTSBrickData (brick64x64Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/64x64.blb";
	category = "baseplates";
	subCategory = "plain";
	uiName = "64x64";
};

datablock fxDTSBrickData (brick2x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x2.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x2";
};

datablock fxDTSBrickData (brick2x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x3.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x3";
};

datablock fxDTSBrickData (brick2x4Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x4.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x4";
};

datablock fxDTSBrickData (brick2x5Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x5.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x5";
};

datablock fxDTSBrickData (brick2x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x6.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x6";
};

datablock fxDTSBrickData (brick2x7Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x7.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x7";
};

datablock fxDTSBrickData (brick2x8Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x8.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x8";
};

datablock fxDTSBrickData (brick2x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x9.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x9";
};

datablock fxDTSBrickData (brick2x10Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x10.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x10";
};

datablock fxDTSBrickData (brick2x11Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x11.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x11";
};

datablock fxDTSBrickData (brick2x12Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x12.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x12";
};

datablock fxDTSBrickData (brick2x13Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x13.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x13";
};

datablock fxDTSBrickData (brick2x14Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x14.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x14";
};

datablock fxDTSBrickData (brick2x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x15.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x15";
};

datablock fxDTSBrickData (brick2x16Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x16.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x16";
};

datablock fxDTSBrickData (brick2x17Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x17.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x17";
};

datablock fxDTSBrickData (brick2x18Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x18.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x18";
};

datablock fxDTSBrickData (brick2x19Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x19.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x19";
};

datablock fxDTSBrickData (brick2x20Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x20.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x20";
};

datablock fxDTSBrickData (brick2x21Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x21.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x21";
};

datablock fxDTSBrickData (brick2x22Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x22.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x22";
};

datablock fxDTSBrickData (brick2x23Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x23.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x23";
};

datablock fxDTSBrickData (brick2x24Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x24.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x24";
};

datablock fxDTSBrickData (brick2x25Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x25.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x25";
};

datablock fxDTSBrickData (brick2x26Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x26.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x26";
};

datablock fxDTSBrickData (brick2x27Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x27.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x27";
};

datablock fxDTSBrickData (brick2x28Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x28.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x28";
};

datablock fxDTSBrickData (brick2x29Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x29.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x29";
};

datablock fxDTSBrickData (brick2x30Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x30.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x30";
};

datablock fxDTSBrickData (brick2x31Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x31.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x31";
};

datablock fxDTSBrickData (brick2x32Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x32.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x32";
};

datablock fxDTSBrickData (brick2x33Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x33.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x33";
};

datablock fxDTSBrickData (brick2x34Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x34.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x34";
};

datablock fxDTSBrickData (brick2x35Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x35.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x35";
};

datablock fxDTSBrickData (brick2x36Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x36.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x36";
};

datablock fxDTSBrickData (brick2x37Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x37.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x37";
};

datablock fxDTSBrickData (brick2x38Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x38.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x38";
};

datablock fxDTSBrickData (brick2x39Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x39.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x39";
};

datablock fxDTSBrickData (brick2x40Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x40.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x40";
};

datablock fxDTSBrickData (brick2x41Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x41.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x41";
};

datablock fxDTSBrickData (brick2x42Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x42.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x42";
};

datablock fxDTSBrickData (brick2x42Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x42.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x42";
};

datablock fxDTSBrickData (brick2x43Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x43.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x43";
};

datablock fxDTSBrickData (brick2x44Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x44.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x44";
};

datablock fxDTSBrickData (brick2x45Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x45.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x45";
};

datablock fxDTSBrickData (brick2x46Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x46.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x46";
};

datablock fxDTSBrickData (brick2x47Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x47.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x47";
};

datablock fxDTSBrickData (brick2x48Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x48.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x48";
};

datablock fxDTSBrickData (brick2x49Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x49.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x49";
};

datablock fxDTSBrickData (brick2x50Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x50.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x50";
};

datablock fxDTSBrickData (brick2x51Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x51.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x51";
};

datablock fxDTSBrickData (brick2x52Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x52.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x52";
};

datablock fxDTSBrickData (brick2x53Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x53.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x53";
};

datablock fxDTSBrickData (brick2x54Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x54.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x54";
};

datablock fxDTSBrickData (brick2x55Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x55.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x55";
};

datablock fxDTSBrickData (brick2x56Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x56.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x56";
};

datablock fxDTSBrickData (brick2x57Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x57.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x57";
};

datablock fxDTSBrickData (brick2x58Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x58.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x58";
};

datablock fxDTSBrickData (brick2x59Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x59.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x59";
};

datablock fxDTSBrickData (brick2x60Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x60.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x60";
};

datablock fxDTSBrickData (brick2x61Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x61.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x61";
};

datablock fxDTSBrickData (brick2x62Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x62.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x62";
};

datablock fxDTSBrickData (brick2x63Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x63.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x63";
};

datablock fxDTSBrickData (brick2x64Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x64.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x64";
};

datablock fxDTSBrickData (brick1x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x1.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x1";
};

datablock fxDTSBrickData (brick1x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x2.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x2";
};

datablock fxDTSBrickData (brick1x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x3.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x3";
};

datablock fxDTSBrickData (brick1x4Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x4.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x4";
};

datablock fxDTSBrickData (brick1x5Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x5.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x5";
};

datablock fxDTSBrickData (brick1x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x6.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x6";
};

datablock fxDTSBrickData (brick1x7Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x7.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x7";
};

datablock fxDTSBrickData (brick1x8Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x8.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x8";
};

datablock fxDTSBrickData (brick1x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x9.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x9";
};

datablock fxDTSBrickData (brick1x10Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x10.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x10";
};

datablock fxDTSBrickData (brick1x11Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x11.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x11";
};

datablock fxDTSBrickData (brick1x12Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x12.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x12";
};

datablock fxDTSBrickData (brick1x13Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x13.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x13";
};

datablock fxDTSBrickData (brick1x14Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x14.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x14";
};

datablock fxDTSBrickData (brick1x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x15.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x15";
};

datablock fxDTSBrickData (brick1x16Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x16.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x16";
};

datablock fxDTSBrickData (brick1x17Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x17.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x17";
};

datablock fxDTSBrickData (brick1x18Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x18.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x18";
};

datablock fxDTSBrickData (brick1x19Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x19.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x19";
};

datablock fxDTSBrickData (brick1x20Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x20.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x20";
};

datablock fxDTSBrickData (brick1x21Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x21.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x21";
};

datablock fxDTSBrickData (brick1x22Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x22.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x22";
};

datablock fxDTSBrickData (brick1x23Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x23.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x23";
};

datablock fxDTSBrickData (brick1x24Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x24.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x24";
};

datablock fxDTSBrickData (brick1x25Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x25.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x25";
};

datablock fxDTSBrickData (brick1x26Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x26.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x26";
};

datablock fxDTSBrickData (brick1x27Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x27.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x27";
};

datablock fxDTSBrickData (brick1x28Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x28.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x28";
};

datablock fxDTSBrickData (brick1x29Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x29.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x29";
};

datablock fxDTSBrickData (brick1x30Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x30.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x30";
};

datablock fxDTSBrickData (brick1x31Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x31.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x31";
};

datablock fxDTSBrickData (brick1x32Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x32.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x32";
};

datablock fxDTSBrickData (brick1x33Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x33.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x33";
};

datablock fxDTSBrickData (brick1x34Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x34.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x34";
};

datablock fxDTSBrickData (brick1x35Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x35.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x35";
};

datablock fxDTSBrickData (brick1x36Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x36.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x36";
};

datablock fxDTSBrickData (brick1x37Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x37.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x37";
};

datablock fxDTSBrickData (brick1x38Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x38.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x38";
};

datablock fxDTSBrickData (brick1x39Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x39.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x39";
};

datablock fxDTSBrickData (brick1x40Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x40.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x40";
};

datablock fxDTSBrickData (brick1x41Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x41.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x41";
};

datablock fxDTSBrickData (brick1x42Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x42.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x42";
};

datablock fxDTSBrickData (brick1x43Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x43.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x43";
};

datablock fxDTSBrickData (brick1x44Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x44.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x44";
};

datablock fxDTSBrickData (brick1x45Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x45.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x45";
};

datablock fxDTSBrickData (brick1x46Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x46.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x46";
};

datablock fxDTSBrickData (brick1x47Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x47.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x47";
};

datablock fxDTSBrickData (brick1x48Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x48.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x48";
};

datablock fxDTSBrickData (brick1x49Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x49.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x49";
};

datablock fxDTSBrickData (brick1x50Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x50.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x50";
};

datablock fxDTSBrickData (brick1x51Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x51.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x51";
};

datablock fxDTSBrickData (brick1x52Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x52.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x52";
};

datablock fxDTSBrickData (brick1x53Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x53.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x53";
};

datablock fxDTSBrickData (brick1x54Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x54.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x54";
};

datablock fxDTSBrickData (brick1x55Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x55.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x55";
};

datablock fxDTSBrickData (brick1x56Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x56.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x56";
};

datablock fxDTSBrickData (brick1x57Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x57.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x57";
};

datablock fxDTSBrickData (brick1x58Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x58.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x58";
};

datablock fxDTSBrickData (brick1x59Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x59.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x59";
};

datablock fxDTSBrickData (brick1x60Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x60.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x60";
};

datablock fxDTSBrickData (brick1x61Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x61.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x61";
};

datablock fxDTSBrickData (brick1x62Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x62.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x62";
};

datablock fxDTSBrickData (brick1x63Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x63.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x63";
};

datablock fxDTSBrickData (brick1x64Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x64.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x64";
};

datablock fxDTSBrickData (brick1x1x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x1x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x1x15";
};

datablock fxDTSBrickData (brick1x2x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x2x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x2x15";
};

datablock fxDTSBrickData (brick1x3x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x3x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x3x15";
};

datablock fxDTSBrickData (brick1x4x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x4x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x4x15";
};

datablock fxDTSBrickData (brick1x5x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x5x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x5x15";
};

datablock fxDTSBrickData (brick1x6x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x6x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x6x15";
};

datablock fxDTSBrickData (brick1x7x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x7x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x7x15";
};

datablock fxDTSBrickData (brick1x8x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x8x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x8x15";
};

datablock fxDTSBrickData (brick1x9x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x9x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x9x15";
};

datablock fxDTSBrickData (brick1x1x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x10x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x10x15";
};

datablock fxDTSBrickData (brick1x11x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x11x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x11x15";
};

datablock fxDTSBrickData (brick1x12x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x12x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x12x15";
};

datablock fxDTSBrickData (brick1x13x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x13x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x13x15";
};

datablock fxDTSBrickData (brick1x14x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x14x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x14x15";
};

datablock fxDTSBrickData (brick1x15x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x15x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x15x15";
};

datablock fxDTSBrickData (brick1x16x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x16x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x16x15";
};

datablock fxDTSBrickData (brick1x17x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x17x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x17x15";
};

datablock fxDTSBrickData (brick1x18x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x18x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x18x15";
};

datablock fxDTSBrickData (brick1x19x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x19x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x19x15";
};

datablock fxDTSBrickData (brick1x20x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x20x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x20x15";
};

datablock fxDTSBrickData (brick1x21x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x21x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x21x15";
};

datablock fxDTSBrickData (brick1x22x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x22x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x22x15";
};

datablock fxDTSBrickData (brick1x23x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x23x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x23x15";
};

datablock fxDTSBrickData (brick1x24x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x24x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x24x15";
};

datablock fxDTSBrickData (brick1x25x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x25x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x25x15";
};

datablock fxDTSBrickData (brick1x26x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x26x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x26x15";
};

datablock fxDTSBrickData (brick1x27x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x27x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x27x15";
};

datablock fxDTSBrickData (brick1x28x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x28x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x28x15";
};

datablock fxDTSBrickData (brick1x29x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x29x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x29x15";
};

datablock fxDTSBrickData (brick1x30x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x30x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x30x15";
};

datablock fxDTSBrickData (brick1x31x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x31x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x31x15";
};

datablock fxDTSBrickData (brick1x32x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x32x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x32x15";
};

datablock fxDTSBrickData (brick1x33x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x33x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x33x15";
};

datablock fxDTSBrickData (brick1x34x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x34x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x34x15";
};

datablock fxDTSBrickData (brick1x35x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x35x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x35x15";
};

datablock fxDTSBrickData (brick1x36x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x36x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x36x15";
};

datablock fxDTSBrickData (brick1x37x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x37x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x37x15";
};

datablock fxDTSBrickData (brick1x38x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x38x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x38x15";
};

datablock fxDTSBrickData (brick1x39x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x39x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x39x15";
};

datablock fxDTSBrickData (brick1x40x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x40x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x40x15";
};

datablock fxDTSBrickData (brick1x41x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x41x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x41x15";
};

datablock fxDTSBrickData (brick1x42x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x42x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x42x15";
};

datablock fxDTSBrickData (brick1x43x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x43x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x43x15";
};

datablock fxDTSBrickData (brick1x44x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x44x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x44x15";
};

datablock fxDTSBrickData (brick1x45x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x45x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x45x15";
};

datablock fxDTSBrickData (brick1x46x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x46x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x46x15";
};

datablock fxDTSBrickData (brick1x47x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x47x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x47x15";
};

datablock fxDTSBrickData (brick1x48x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x48x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x48x15";
};

datablock fxDTSBrickData (brick1x49x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x49x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x49x15";
};

datablock fxDTSBrickData (brick1x50x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x50x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x50x15";
};

datablock fxDTSBrickData (brick1x51x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x51x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x51x15";
};

datablock fxDTSBrickData (brick1x52x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x52x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x52x15";
};

datablock fxDTSBrickData (brick1x53x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x53x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x53x15";
};

datablock fxDTSBrickData (brick1x54x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x54x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x54x15";
};

datablock fxDTSBrickData (brick1x55x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x55x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x55x15";
};

datablock fxDTSBrickData (brick1x56x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x56x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x56x15";
};

datablock fxDTSBrickData (brick1x57x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x57x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x57x15";
};

datablock fxDTSBrickData (brick1x58x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x58x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x58x15";
};

datablock fxDTSBrickData (brick1x59x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x59x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x59x15";
};

datablock fxDTSBrickData (brick1x60x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x60x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x60x15";
};

datablock fxDTSBrickData (brick1x61x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x61x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x61x15";
};

datablock fxDTSBrickData (brick1x62x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x62x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x62x15";
};

datablock fxDTSBrickData (brick1x63x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x63x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x63x15";
};

datablock fxDTSBrickData (brick1x64x15Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x64x15.blb";
	category = "Bricks";
	subCategory = "5x height";
	uiName = "1x64x15";
};

datablock fxDTSBrickData (brick8x12Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/8x12.blb";
	category = "Bricks";
	subCategory = "8x";
	uiName = "8x12";
};

datablock fxDTSBrickData (brick10x30Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/10x30.blb";
	category = "Bricks";
	subCategory = "10x";
	uiName = "10x30";
};

datablock fxDTSBrickData (brick10x40Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/10x40.blb";
	category = "Bricks";
	subCategory = "10x";
	uiName = "10x40";
};

datablock fxDTSBrickData (brick10x50Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/10x50.blb";
	category = "Bricks";
	subCategory = "10x";
	uiName = "10x50";
};

datablock fxDTSBrickData (brick10x60Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/10x60.blb";
	category = "Bricks";
	subCategory = "10x";
	uiName = "10x60";
};

datablock fxDTSBrickData (brick12x48Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/12x48.blb";
	category = "Bricks";
	subCategory = "12x";
	uiName = "12x48";
};

datablock fxDTSBrickData (brick12x12Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/12x12.blb";
	category = "Bricks";
	subCategory = "12x";
	uiName = "12x12";
};

datablock fxDTSBrickData (brick12x64Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/12x64.blb";
	category = "Bricks";
	subCategory = "12x";
	uiName = "12x64";
};

datablock fxDTSBrickData (brick12x16Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/12x16.blb";
	category = "Bricks";
	subCategory = "12x";
	uiName = "12x16";
};

datablock fxDTSBrickData (brick16x48x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/16x48x1.blb";
	category = "baseplates";
	subCategory = "plain";
	uiName = "16x48x1";
};

datablock fxDTSBrickData (brick16x64x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/16x64x1.blb";
	category = "baseplates";
	subCategory = "plain";
	uiName = "16x64x1";
};

datablock fxDTSBrickData (brick32x48x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/32x48x1.blb";
	category = "baseplates";
	subCategory = "plain";
	uiName = "32x48x1";
};

datablock fxDTSBrickData (brick32x64x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/32x64x1.blb";
	category = "baseplates";
	subCategory = "plain";
	uiName = "32x64x1";
};

datablock fxDTSBrickData (brick48x64x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/48x64x1.blb";
	category = "baseplates";
	subCategory = "plain";
	uiName = "48x64x1";
};

datablock fxDTSBrickData (brick24x24x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/24x24x1.blb";
	category = "baseplates";
	subCategory = "plain";
	uiName = "24x24x1";
};

datablock fxDTSBrickData (brick24x64x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/24x64x1.blb";
	category = "baseplates";
	subCategory = "plain";
	uiName = "24x64x1";
};

datablock fxDTSBrickData (brick24x24x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/24x24x3.blb";
	category = "baseplates";
	subCategory = "plain";
	uiName = "24x24x3";
};

datablock fxDTSBrickData (brick24x48x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/24x48x3.blb";
	category = "baseplates";
	subCategory = "plain";
	uiName = "24x48x3";
};

datablock fxDTSBrickData (brick24x64x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/24x64x3.blb";
	category = "baseplates";
	subCategory = "plain";
	uiName = "24x64x3";
};

datablock fxDTSBrickData (brick2x3x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x3x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x3x9";
};

datablock fxDTSBrickData (brick2x4x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x4x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x4x9";
};

datablock fxDTSBrickData (brick2x5x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x5x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x5x9";
};

datablock fxDTSBrickData (brick2x6x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x6x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x6x9";
};

datablock fxDTSBrickData (brick2x7x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x7x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x7x9";
};

datablock fxDTSBrickData (brick2x8x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x8x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x8x9";
};

datablock fxDTSBrickData (brick2x9x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x9x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x9x9";
};

datablock fxDTSBrickData (brick2x10x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x10x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x10x9";
};

datablock fxDTSBrickData (brick2x11x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x11x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x11x9";
};

datablock fxDTSBrickData (brick2x12x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x12x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x12x9";
};

datablock fxDTSBrickData (brick2x13x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x13x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x13x9";
};

datablock fxDTSBrickData (brick2x14x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x14x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x14x9";
};

datablock fxDTSBrickData (brick2x15x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x15x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x15x9";
};

datablock fxDTSBrickData (brick2x16x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x16x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x16x9";
};

datablock fxDTSBrickData (brick2x17x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x17x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x17x9";
};

datablock fxDTSBrickData (brick2x18x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x18x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x18x9";
};

datablock fxDTSBrickData (brick2x19x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x19x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x19x9";
};

datablock fxDTSBrickData (brick2x20x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x20x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x20x9";
};

datablock fxDTSBrickData (brick2x21x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x21x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x21x9";
};

datablock fxDTSBrickData (brick2x22x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x22x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x22x9";
};

datablock fxDTSBrickData (brick2x23x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x23x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x23x9";
};

datablock fxDTSBrickData (brick2x24x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x24x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x24x9";
};

datablock fxDTSBrickData (brick2x25x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x25x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x25x9";
};

datablock fxDTSBrickData (brick2x26x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x26x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x26x9";
};

datablock fxDTSBrickData (brick2x27x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x27x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x27x9";
};

datablock fxDTSBrickData (brick2x28x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x28x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x28x9";
};

datablock fxDTSBrickData (brick2x29x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x29x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x29x9";
};

datablock fxDTSBrickData (brick2x30x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x30x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x30x9";
};

datablock fxDTSBrickData (brick2x31x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x31x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x31x9";
};

datablock fxDTSBrickData (brick2x32x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x32x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x32x9";
};

datablock fxDTSBrickData (brick2x33x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x33x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x33x9";
};

datablock fxDTSBrickData (brick2x34x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x34x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x34x9";
};

datablock fxDTSBrickData (brick2x35x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x35x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x35x9";
};

datablock fxDTSBrickData (brick2x36x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x36x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x36x9";
};

datablock fxDTSBrickData (brick2x37x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x37x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x37x9";
};

datablock fxDTSBrickData (brick2x38x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x38x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x38x9";
};

datablock fxDTSBrickData (brick2x39x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x39x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x39x9";
};

datablock fxDTSBrickData (brick2x40x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x40x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x40x9";
};

datablock fxDTSBrickData (brick2x41x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x41x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x41x9";
};

datablock fxDTSBrickData (brick2x42x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x42x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x42x9";
};

datablock fxDTSBrickData (brick2x43x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x43x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x43x9";
};

datablock fxDTSBrickData (brick2x44x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x44x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x44x9";
};

datablock fxDTSBrickData (brick2x45x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x45x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x45x9";
};

datablock fxDTSBrickData (brick2x46x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x46x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x46x9";
};

datablock fxDTSBrickData (brick2x47x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x47x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x47x9";
};

datablock fxDTSBrickData (brick2x48x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x48x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x48x9";
};

datablock fxDTSBrickData (brick2x49x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x49x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x49x9";
};

datablock fxDTSBrickData (brick2x50x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x50x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x50x9";
};

datablock fxDTSBrickData (brick2x51x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x51x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x51x9";
};

datablock fxDTSBrickData (brick2x52x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x52x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x52x9";
};

datablock fxDTSBrickData (brick2x53x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x53x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x53x9";
};

datablock fxDTSBrickData (brick2x54x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x54x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x54x9";
};

datablock fxDTSBrickData (brick2x55x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x55x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x55x9";
};

datablock fxDTSBrickData (brick2x56x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x56x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x56x9";
};

datablock fxDTSBrickData (brick2x57x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x57x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x57x9";
};

datablock fxDTSBrickData (brick2x58x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x58x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x58x9";
};

datablock fxDTSBrickData (brick2x59x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x59x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x59x9";
};

datablock fxDTSBrickData (brick2x60x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x60x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x60x9";
};

datablock fxDTSBrickData (brick2x61x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x61x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x61x9";
};

datablock fxDTSBrickData (brick2x62x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x62x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x62x9";
};

datablock fxDTSBrickData (brick2x63x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x63x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x63x9";
};

datablock fxDTSBrickData (brick2x64x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x64x9.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x64x9";
};

datablock fxDTSBrickData (brick16x16x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/16x16x3.blb";
	category = "baseplates";
	subCategory = "plain";
	uiName = "16x16x3";
};

datablock fxDTSBrickData (brick6x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/6x6.blb";
	category = "Bricks";
	subCategory = "6x";
	uiName = "6x6";
};

datablock fxDTSBrickData (brick6x8Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/6x8.blb";
	category = "Bricks";
	subCategory = "6x";
	uiName = "6x8";
};

datablock fxDTSBrickData (brick6x10Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/6x10.blb";
	category = "Bricks";
	subCategory = "6x";
	uiName = "6x10";
};

datablock fxDTSBrickData (brick6x12Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/6x12.blb";
	category = "Bricks";
	subCategory = "6x";
	uiName = "6x12";
};

datablock fxDTSBrickData (brick6x14Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/6x14.blb";
	category = "Bricks";
	subCategory = "6x";
	uiName = "6x14";
};

datablock fxDTSBrickData (brick6x16Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/6x16.blb";
	category = "Bricks";
	subCategory = "6x";
	uiName = "6x16";
};

datablock fxDTSBrickData (brick6x18Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/6x18.blb";
	category = "Bricks";
	subCategory = "6x";
	uiName = "6x18";
};

datablock fxDTSBrickData (brick6x20Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/6x20.blb";
	category = "Bricks";
	subCategory = "6x";
	uiName = "6x20";
};

datablock fxDTSBrickData (brick6x22Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/6x22.blb";
	category = "Bricks";
	subCategory = "6x";
	uiName = "6x22";
};

datablock fxDTSBrickData (brick6x24Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/6x24.blb";
	category = "Bricks";
	subCategory = "6x";
	uiName = "6x24";
};

datablock fxDTSBrickData (brick6x26Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/6x26.blb";
	category = "Bricks";
	subCategory = "6x";
	uiName = "6x26";
};

datablock fxDTSBrickData (brick6x28Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/6x28.blb";
	category = "Bricks";
	subCategory = "6x";
	uiName = "6x28";
};

datablock fxDTSBrickData (brick6x30Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/6x30.blb";
	category = "Bricks";
	subCategory = "6x";
	uiName = "6x30";
};

datablock fxDTSBrickData (brick6x32Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/6x32.blb";
	category = "Bricks";
	subCategory = "6x";
	uiName = "6x32";
};

datablock fxDTSBrickData (brick6x34Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/6x34.blb";
	category = "Bricks";
	subCategory = "6x";
	uiName = "6x34";
};

datablock fxDTSBrickData (brick6x36Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/6x36.blb";
	category = "Bricks";
	subCategory = "6x";
	uiName = "6x36";
};

datablock fxDTSBrickData (brick6x38Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/6x38.blb";
	category = "Bricks";
	subCategory = "6x";
	uiName = "6x38";
};

datablock fxDTSBrickData (brick6x40Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/6x40.blb";
	category = "Bricks";
	subCategory = "6x";
	uiName = "6x40";
};

datablock fxDTSBrickData (brick6x42Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/6x42.blb";
	category = "Bricks";
	subCategory = "6x";
	uiName = "6x42";
};

datablock fxDTSBrickData (brick6x44Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/6x44.blb";
	category = "Bricks";
	subCategory = "6x";
	uiName = "6x44";
};

datablock fxDTSBrickData (brick6x46Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/6x46.blb";
	category = "Bricks";
	subCategory = "6x";
	uiName = "6x46";
};

datablock fxDTSBrickData (brick6x48Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/6x48.blb";
	category = "Bricks";
	subCategory = "6x";
	uiName = "6x48";
};

datablock fxDTSBrickData (brick6x50Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/6x50.blb";
	category = "Bricks";
	subCategory = "6x";
	uiName = "6x50";
};

datablock fxDTSBrickData (brick6x52Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/6x52.blb";
	category = "Bricks";
	subCategory = "6x";
	uiName = "6x52";
};

datablock fxDTSBrickData (brick6x54Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/6x54.blb";
	category = "Bricks";
	subCategory = "6x";
	uiName = "6x54";
};

datablock fxDTSBrickData (brick6x56Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/6x56.blb";
	category = "Bricks";
	subCategory = "6x";
	uiName = "6x56";
};

datablock fxDTSBrickData (brick6x58Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/6x58.blb";
	category = "Bricks";
	subCategory = "6x";
	uiName = "6x58";
};

datablock fxDTSBrickData (brick6x60Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/6x60.blb";
	category = "Bricks";
	subCategory = "6x";
	uiName = "6x60";
};

datablock fxDTSBrickData (brick6x62Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/6x62.blb";
	category = "Bricks";
	subCategory = "6x";
	uiName = "6x62";
};

datablock fxDTSBrickData (brick6x64Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/6x64.blb";
	category = "Bricks";
	subCategory = "6x";
	uiName = "6x64";
};

datablock fxDTSBrickData (brick1x1x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x1x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x1x2";
};

datablock fxDTSBrickData (brick1x2x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x2x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x2x2";
};

datablock fxDTSBrickData (brick1x3x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x3x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x3x2";
};

datablock fxDTSBrickData (brick1x4x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x4x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x4x2";
};

datablock fxDTSBrickData (brick1x5x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x5x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x5x2";
};

datablock fxDTSBrickData (brick1x6x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x6x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x6x2";
};

datablock fxDTSBrickData (brick1x7x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x7x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x7x2";
};

datablock fxDTSBrickData (brick1x8x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x8x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x8x2";
};

datablock fxDTSBrickData (brick1x9x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x9x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x9x2";
};

datablock fxDTSBrickData (brick1x10x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x10x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x10x2";
};

datablock fxDTSBrickData (brick1x11x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x11x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x11x2";
};

datablock fxDTSBrickData (brick1x12x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x12x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x12x2";
};

datablock fxDTSBrickData (brick1x13x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x13x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x13x2";
};

datablock fxDTSBrickData (brick1x14x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x14x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x14x2";
};

datablock fxDTSBrickData (brick1x15x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x15x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x15x2";
};

datablock fxDTSBrickData (brick1x16x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x16x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x16x2";
};

datablock fxDTSBrickData (brick1x17x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x17x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x17x2";
};

datablock fxDTSBrickData (brick1x18x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x18x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x18x2";
};

datablock fxDTSBrickData (brick1x19x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x19x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x19x2";
};

datablock fxDTSBrickData (brick1x20x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x20x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x20x2";
};

datablock fxDTSBrickData (brick1x21x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x21x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x21x2";
};

datablock fxDTSBrickData (brick1x22x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x22x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x22x2";
};

datablock fxDTSBrickData (brick1x23x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x23x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x23x2";
};

datablock fxDTSBrickData (brick1x24x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x24x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x24x2";
};

datablock fxDTSBrickData (brick1x25x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x25x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x25x2";
};

datablock fxDTSBrickData (brick1x26x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x26x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x26x2";
};

datablock fxDTSBrickData (brick1x27x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x27x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x27x2";
};

datablock fxDTSBrickData (brick1x28x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x28x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x28x2";
};

datablock fxDTSBrickData (brick1x29x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x29x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x29x2";
};

datablock fxDTSBrickData (brick1x30x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x30x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x30x2";
};

datablock fxDTSBrickData (brick1x31x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x31x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x31x2";
};

datablock fxDTSBrickData (brick1x32x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x32x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x32x2";
};

datablock fxDTSBrickData (brick1x33x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x33x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x33x2";
};

datablock fxDTSBrickData (brick1x34x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x34x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x34x2";
};

datablock fxDTSBrickData (brick1x35x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x35x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x35x2";
};

datablock fxDTSBrickData (brick1x36x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x36x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x36x2";
};

datablock fxDTSBrickData (brick1x37x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x37x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x37x2";
};

datablock fxDTSBrickData (brick1x38x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x38x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x38x2";
};

datablock fxDTSBrickData (brick1x39x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x39x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x39x2";
};

datablock fxDTSBrickData (brick1x40x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x40x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x40x2";
};

datablock fxDTSBrickData (brick1x41x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x41x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x41x2";
};

datablock fxDTSBrickData (brick1x42x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x42x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x42x2";
};

datablock fxDTSBrickData (brick1x43x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x43x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x43x2";
};

datablock fxDTSBrickData (brick1x44x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x44x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x44x2";
};

datablock fxDTSBrickData (brick1x45x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x45x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x45x2";
};

datablock fxDTSBrickData (brick1x46x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x46x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x46x2";
};

datablock fxDTSBrickData (brick1x47x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x47x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x47x2";
};

datablock fxDTSBrickData (brick1x48x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x48x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x48x2";
};

datablock fxDTSBrickData (brick1x49x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x49x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x49x2";
};

datablock fxDTSBrickData (brick1x50x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x50x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x50x2";
};

datablock fxDTSBrickData (brick1x51x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x51x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x51x2";
};

datablock fxDTSBrickData (brick1x52x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x52x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x52x2";
};

datablock fxDTSBrickData (brick1x53x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x53x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x53x2";
};

datablock fxDTSBrickData (brick1x54x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x54x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x54x2";
};

datablock fxDTSBrickData (brick1x55x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x55x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x55x2";
};

datablock fxDTSBrickData (brick1x56x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x56x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x56x2";
};

datablock fxDTSBrickData (brick1x57x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x57x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x57x2";
};

datablock fxDTSBrickData (brick1x58x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x58x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x58x2";
};

datablock fxDTSBrickData (brick1x59x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x59x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x59x2";
};

datablock fxDTSBrickData (brick1x60x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x60x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x60x2";
};

datablock fxDTSBrickData (brick1x61x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x61x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x61x2";
};

datablock fxDTSBrickData (brick1x62x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x62x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x62x2";
};

datablock fxDTSBrickData (brick1x63x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x63x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x63x2";
};

datablock fxDTSBrickData (brick1x64x2Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x64x2.blb";
	category = "plates";
	subCategory = "1x2x";
	uiName = "1x64x2";
};

datablock fxDTSBrickData (brick3x3x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x3x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x3x3";
};

datablock fxDTSBrickData (brick3x4x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x4x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x4x3";
};

datablock fxDTSBrickData (brick3x5x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x5x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x5x3";
};

datablock fxDTSBrickData (brick3x6x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x6x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x6x3";
};

datablock fxDTSBrickData (brick3x7x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x7x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x7x3";
};

datablock fxDTSBrickData (brick3x8x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x8x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x8x3";
};

datablock fxDTSBrickData (brick3x9x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x9x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x9x3";
};

datablock fxDTSBrickData (brick3x10x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x10x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x10x3";
};

datablock fxDTSBrickData (brick3x11x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x11x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x11x3";
};

datablock fxDTSBrickData (brick3x12x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x12x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x12x3";
};

datablock fxDTSBrickData (brick3x13x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x13x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x13x3";
};

datablock fxDTSBrickData (brick3x14x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x14x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x14x3";
};

datablock fxDTSBrickData (brick3x15x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x15x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x15x3";
};

datablock fxDTSBrickData (brick3x16x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x16x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x16x3";
};

datablock fxDTSBrickData (brick3x17x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x17x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x17x3";
};

datablock fxDTSBrickData (brick3x18x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x18x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x18x3";
};

datablock fxDTSBrickData (brick3x19x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x19x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x19x3";
};

datablock fxDTSBrickData (brick3x20x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x20x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x20x3";
};

datablock fxDTSBrickData (brick3x21x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x21x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x21x3";
};

datablock fxDTSBrickData (brick3x22x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x22x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x22x3";
};

datablock fxDTSBrickData (brick3x23x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x23x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x23x3";
};

datablock fxDTSBrickData (brick3x24x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x24x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x24x3";
};

datablock fxDTSBrickData (brick3x25x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x25x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x25x3";
};

datablock fxDTSBrickData (brick3x26x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x26x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x26x3";
};

datablock fxDTSBrickData (brick3x27x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x27x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x27x3";
};

datablock fxDTSBrickData (brick3x28x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x28x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x28x3";
};

datablock fxDTSBrickData (brick3x29x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x29x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x29x3";
};

datablock fxDTSBrickData (brick3x30x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x30x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x30x3";
};

datablock fxDTSBrickData (brick3x31x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x31x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x31x3";
};

datablock fxDTSBrickData (brick3x32x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x32x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x32x3";
};

datablock fxDTSBrickData (brick3x33x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x33x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x33x3";
};

datablock fxDTSBrickData (brick3x34x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x34x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x34x3";
};

datablock fxDTSBrickData (brick3x35x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x35x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x35x3";
};

datablock fxDTSBrickData (brick3x36x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x36x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x36x3";
};

datablock fxDTSBrickData (brick3x37x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x37x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x37x3";
};

datablock fxDTSBrickData (brick3x38x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x38x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x38x3";
};

datablock fxDTSBrickData (brick3x39x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x39x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x39x3";
};

datablock fxDTSBrickData (brick3x40x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x40x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x40x3";
};

datablock fxDTSBrickData (brick3x41x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x41x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x41x3";
};

datablock fxDTSBrickData (brick3x42x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x42x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x42x3";
};

datablock fxDTSBrickData (brick3x43x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x43x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x43x3";
};

datablock fxDTSBrickData (brick3x44x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x44x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x44x3";
};

datablock fxDTSBrickData (brick3x45x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x45x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x45x3";
};

datablock fxDTSBrickData (brick3x46x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x46x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x46x3";
};

datablock fxDTSBrickData (brick3x47x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x47x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x47x3";
};

datablock fxDTSBrickData (brick3x48x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x48x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x48x3";
};

datablock fxDTSBrickData (brick3x49x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x49x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x49x3";
};

datablock fxDTSBrickData (brick3x50x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x50x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x50x3";
};

datablock fxDTSBrickData (brick3x51x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x51x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x51x3";
};

datablock fxDTSBrickData (brick3x52x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x52x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x52x3";
};

datablock fxDTSBrickData (brick3x53x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x53x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x53x3";
};

datablock fxDTSBrickData (brick3x54x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x54x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x54x3";
};

datablock fxDTSBrickData (brick3x55x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x55x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x55x3";
};

datablock fxDTSBrickData (brick3x56x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x56x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x56x3";
};

datablock fxDTSBrickData (brick3x57x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x57x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x57x3";
};

datablock fxDTSBrickData (brick3x58x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x58x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x58x3";
};

datablock fxDTSBrickData (brick3x59x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x59x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x59x3";
};

datablock fxDTSBrickData (brick3x60x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x60x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x60x3";
};

datablock fxDTSBrickData (brick3x61x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x61x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x61x3";
};

datablock fxDTSBrickData (brick3x62x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x62x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x62x3";
};

datablock fxDTSBrickData (brick3x63x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x63x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x63x3";
};

datablock fxDTSBrickData (brick3x64x3Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/3x64x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x64x3";
};

datablock fxDTSBrickData (brick1x1x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x1x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x1x9";
};

datablock fxDTSBrickData (brick1x2x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x2x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x2x9";
};

datablock fxDTSBrickData (brick1x3x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x3x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x3x9";
};

datablock fxDTSBrickData (brick1x4x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x4x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x4x9";
};

datablock fxDTSBrickData (brick1x5x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x5x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x5x9";
};

datablock fxDTSBrickData (brick1x6x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x6x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x6x9";
};

datablock fxDTSBrickData (brick1x7x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x7x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x7x9";
};

datablock fxDTSBrickData (brick1x8x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x8x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x8x9";
};

datablock fxDTSBrickData (brick1x9x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x9x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x9x9";
};

datablock fxDTSBrickData (brick1x10x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x10x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x10x9";
};

datablock fxDTSBrickData (brick1x11x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x11x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x11x9";
};

datablock fxDTSBrickData (brick1x12x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x12x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x12x9";
};

datablock fxDTSBrickData (brick1x13x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x13x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x13x9";
};

datablock fxDTSBrickData (brick1x14x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x14x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x14x9";
};

datablock fxDTSBrickData (brick1x15x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x15x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x15x9";
};

datablock fxDTSBrickData (brick1x16x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x16x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x16x9";
};

datablock fxDTSBrickData (brick1x17x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x17x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x17x9";
};

datablock fxDTSBrickData (brick1x18x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x18x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x18x9";
};

datablock fxDTSBrickData (brick1x19x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x19x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x19x9";
};

datablock fxDTSBrickData (brick1x20x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x20x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x20x9";
};

datablock fxDTSBrickData (brick1x21x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x21x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x21x9";
};

datablock fxDTSBrickData (brick1x22x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x22x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x22x9";
};

datablock fxDTSBrickData (brick1x23x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x23x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x23x9";
};

datablock fxDTSBrickData (brick1x24x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x24x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x24x9";
};

datablock fxDTSBrickData (brick1x25x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x25x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x25x9";
};

datablock fxDTSBrickData (brick1x26x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x26x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x26x9";
};

datablock fxDTSBrickData (brick1x27x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x27x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x27x9";
};

datablock fxDTSBrickData (brick1x28x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x28x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x28x9";
};

datablock fxDTSBrickData (brick1x29x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x29x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x29x9";
};

datablock fxDTSBrickData (brick1x30x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x30x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x30x9";
};

datablock fxDTSBrickData (brick1x31x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x31x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x31x9";
};

datablock fxDTSBrickData (brick1x32x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x32x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x32x9";
};

datablock fxDTSBrickData (brick1x33x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x33x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x33x9";
};

datablock fxDTSBrickData (brick1x34x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x34x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x34x9";
};

datablock fxDTSBrickData (brick1x35x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x35x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x35x9";
};

datablock fxDTSBrickData (brick1x36x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x36x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x36x9";
};

datablock fxDTSBrickData (brick1x37x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x37x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x37x9";
};

datablock fxDTSBrickData (brick1x38x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x38x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x38x9";
};

datablock fxDTSBrickData (brick1x39x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x39x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x39x9";
};

datablock fxDTSBrickData (brick1x40x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x40x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x40x9";
};

datablock fxDTSBrickData (brick1x41x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x41x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x41x9";
};

datablock fxDTSBrickData (brick1x42x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x42x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x42x9";
};

datablock fxDTSBrickData (brick1x43x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x43x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x43x9";
};

datablock fxDTSBrickData (brick1x44x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x44x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x44x9";
};

datablock fxDTSBrickData (brick1x45x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x45x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x45x9";
};

datablock fxDTSBrickData (brick1x46x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x46x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x46x9";
};

datablock fxDTSBrickData (brick1x47x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x47x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x47x9";
};

datablock fxDTSBrickData (brick1x48x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x48x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x48x9";
};

datablock fxDTSBrickData (brick1x49x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x49x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x49x9";
};

datablock fxDTSBrickData (brick1x50x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x50x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x50x9";
};

datablock fxDTSBrickData (brick1x51x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x51x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x51x9";
};

datablock fxDTSBrickData (brick1x52x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x52x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x52x9";
};

datablock fxDTSBrickData (brick1x53x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x53x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x53x9";
};

datablock fxDTSBrickData (brick1x54x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x54x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x54x9";
};

datablock fxDTSBrickData (brick1x55x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x55x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x55x9";
};

datablock fxDTSBrickData (brick1x56x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x56x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x56x9";
};

datablock fxDTSBrickData (brick1x57x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x57x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x57x9";
};

datablock fxDTSBrickData (brick1x58x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x58x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x58x9";
};

datablock fxDTSBrickData (brick1x59x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x59x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x59x9";
};

datablock fxDTSBrickData (brick1x60x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x60x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x60x9";
};

datablock fxDTSBrickData (brick1x61x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x61x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x61x9";
};

datablock fxDTSBrickData (brick1x62x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x62x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x62x9";
};

datablock fxDTSBrickData (brick1x63x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x63x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x63x9";
};

datablock fxDTSBrickData (brick1x64x9Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x64x9.blb";
	category = "Bricks";
	subCategory = "3x 1x height";
	uiName = "1x64x9";
};

datablock fxDTSBrickData (brick1x1x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x1x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x1x1";
};

datablock fxDTSBrickData (brick1x2x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x2x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x2x1";
};

datablock fxDTSBrickData (brick1x3x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x3x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x3x1";
};

datablock fxDTSBrickData (brick1x4x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x4x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x4x1";
};

datablock fxDTSBrickData (brick1x5x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x5x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x5x1";
};

datablock fxDTSBrickData (brick1x6x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x6x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x6x1";
};

datablock fxDTSBrickData (brick1x7x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x7x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x7x1";
};

datablock fxDTSBrickData (brick1x8x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x8x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x8x1";
};

datablock fxDTSBrickData (brick1x9x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x9x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x9x1";
};

datablock fxDTSBrickData (brick1x10x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x10x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x10x1";
};

datablock fxDTSBrickData (brick1x11x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x11x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x11x1";
};

datablock fxDTSBrickData (brick1x12x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x12x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x12x1";
};

datablock fxDTSBrickData (brick1x13x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x13x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x13x1";
};

datablock fxDTSBrickData (brick1x14x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x14x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x14x1";
};

datablock fxDTSBrickData (brick1x15x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x15x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x15x1";
};

datablock fxDTSBrickData (brick1x16x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x16x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x16x1";
};

datablock fxDTSBrickData (brick1x17x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x17x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x17x1";
};

datablock fxDTSBrickData (brick1x18x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x18x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x18x1";
};

datablock fxDTSBrickData (brick1x19x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x19x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x19x1";
};

datablock fxDTSBrickData (brick1x20x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x20x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x20x1";
};

datablock fxDTSBrickData (brick1x21x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x21x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x21x1";
};

datablock fxDTSBrickData (brick1x22x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x22x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x22x1";
};

datablock fxDTSBrickData (brick1x23x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x23x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x23x1";
};

datablock fxDTSBrickData (brick1x24x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x24x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x24x1";
};

datablock fxDTSBrickData (brick1x25x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x25x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x25x1";
};

datablock fxDTSBrickData (brick1x26x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x26x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x26x1";
};

datablock fxDTSBrickData (brick1x27x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x27x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x27x1";
};

datablock fxDTSBrickData (brick1x28x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x28x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x28x1";
};

datablock fxDTSBrickData (brick1x29x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x29x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x29x1";
};

datablock fxDTSBrickData (brick1x30x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x30x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x30x1";
};

datablock fxDTSBrickData (brick1x31x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x31x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x31x1";
};

datablock fxDTSBrickData (brick1x32x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x32x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x32x1";
};

datablock fxDTSBrickData (brick1x33x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x33x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x33x1";
};

datablock fxDTSBrickData (brick1x34x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x34x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x34x1";
};

datablock fxDTSBrickData (brick1x35x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x35x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x35x1";
};

datablock fxDTSBrickData (brick1x36x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x36x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x36x1";
};

datablock fxDTSBrickData (brick1x37x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x37x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x37x1";
};

datablock fxDTSBrickData (brick1x38x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x38x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x38x1";
};

datablock fxDTSBrickData (brick1x39x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x39x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x39x1";
};

datablock fxDTSBrickData (brick1x40x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x40x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x40x1";
};

datablock fxDTSBrickData (brick1x41x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x41x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x41x1";
};

datablock fxDTSBrickData (brick1x42x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x42x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x42x1";
};

datablock fxDTSBrickData (brick1x43x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x43x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x43x1";
};

datablock fxDTSBrickData (brick1x44x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x44x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x44x1";
};

datablock fxDTSBrickData (brick1x45x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x45x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x45x1";
};

datablock fxDTSBrickData (brick1x46x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x46x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x46x1";
};

datablock fxDTSBrickData (brick1x47x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x47x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x47x1";
};

datablock fxDTSBrickData (brick1x48x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x48x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x48x1";
};

datablock fxDTSBrickData (brick1x49x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x49x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x49x1";
};

datablock fxDTSBrickData (brick1x50x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x50x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x50x1";
};

datablock fxDTSBrickData (brick1x51x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x51x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x51x1";
};

datablock fxDTSBrickData (brick1x52x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x52x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x52x1";
};

datablock fxDTSBrickData (brick1x53x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x53x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x53x1";
};

datablock fxDTSBrickData (brick1x54x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x54x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x54x1";
};

datablock fxDTSBrickData (brick1x55x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x55x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x55x1";
};

datablock fxDTSBrickData (brick1x56x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x56x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x56x1";
};

datablock fxDTSBrickData (brick1x57x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x57x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x57x1";
};

datablock fxDTSBrickData (brick1x58x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x58x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x58x1";
};

datablock fxDTSBrickData (brick1x59x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x59x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x59x1";
};

datablock fxDTSBrickData (brick1x60x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x60x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x60x1";
};

datablock fxDTSBrickData (brick1x61x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x61x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x61x1";
};

datablock fxDTSBrickData (brick1x62x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x62x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x62x1";
};

datablock fxDTSBrickData (brick1x63x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x63x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x63x1";
};

datablock fxDTSBrickData (brick1x64x1Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/1x64x1.blb";
	category = "plates";
	subCategory = "1x";
	uiName = "1x64x1";
};

datablock fxDTSBrickData (brick2x2x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x2x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x2x6";
};

datablock fxDTSBrickData (brick2x3x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x3x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x3x6";
};

datablock fxDTSBrickData (brick2x4x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x4x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x4x6";
};

datablock fxDTSBrickData (brick2x5x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x5x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x5x6";
};

datablock fxDTSBrickData (brick2x6x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x6x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x6x6";
};

datablock fxDTSBrickData (brick2x7x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x7x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x7x6";
};

datablock fxDTSBrickData (brick2x8x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x8x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x8x6";
};

datablock fxDTSBrickData (brick2x9x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x9x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x9x6";
};

datablock fxDTSBrickData (brick2x10x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x10x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x10x6";
};
datablock fxDTSBrickData (brick2x11x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x11x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x11x6";
};

datablock fxDTSBrickData (brick2x12x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x12x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x12x6";
};

datablock fxDTSBrickData (brick2x13x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x13x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x13x6";
};

datablock fxDTSBrickData (brick2x14x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x14x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x14x6";
};

datablock fxDTSBrickData (brick2x15x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x15x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x15x6";
};

datablock fxDTSBrickData (brick2x16x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x16x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x16x6";
};

datablock fxDTSBrickData (brick2x17x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x17x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x17x6";
};

datablock fxDTSBrickData (brick2x18x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x18x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x18x6";
};

datablock fxDTSBrickData (brick2x19x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x19x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x19x6";
};

datablock fxDTSBrickData (brick2x20x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x20x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x20x6";
};

datablock fxDTSBrickData (brick2x21x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x21x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x21x6";
};

datablock fxDTSBrickData (brick2x22x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x22x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x22x6";
};

datablock fxDTSBrickData (brick2x23x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x23x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x23x6";
};

datablock fxDTSBrickData (brick2x24x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x24x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x24x6";
};

datablock fxDTSBrickData (brick2x25x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x25x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x25x6";
};

datablock fxDTSBrickData (brick2x26x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x26x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x26x6";
};

datablock fxDTSBrickData (brick2x27x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x27x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x27x6";
};

datablock fxDTSBrickData (brick2x28x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x28x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x28x6";
};

datablock fxDTSBrickData (brick2x29x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x29x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x29x6";
};

datablock fxDTSBrickData (brick2x30x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x30x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x30x6";
};

datablock fxDTSBrickData (brick2x31x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x31x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x31x6";
};

datablock fxDTSBrickData (brick2x32x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x32x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x32x6";
};

datablock fxDTSBrickData (brick2x33x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x33x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x33x6";
};

datablock fxDTSBrickData (brick2x34x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x34x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x34x6";
};

datablock fxDTSBrickData (brick2x35x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x35x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x35x6";
};

datablock fxDTSBrickData (brick2x36x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x36x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x36x6";
};

datablock fxDTSBrickData (brick2x37x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x37x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x37x6";
};

datablock fxDTSBrickData (brick2x38x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x38x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x38x6";
};

datablock fxDTSBrickData (brick2x39x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x39x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x39x6";
};

datablock fxDTSBrickData (brick2x40x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x40x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x40x6";
};

datablock fxDTSBrickData (brick2x41x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x41x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x41x6";
};

datablock fxDTSBrickData (brick2x42x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x42x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x42x6";
};

datablock fxDTSBrickData (brick2x43x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x43x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x43x6";
};

datablock fxDTSBrickData (brick2x44x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x44x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x44x6";
};

datablock fxDTSBrickData (brick2x45x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x45x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x45x6";
};

datablock fxDTSBrickData (brick2x46x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x46x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x46x6";
};

datablock fxDTSBrickData (brick2x47x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x47x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x47x6";
};

datablock fxDTSBrickData (brick2x48x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x48x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x48x6";
};

datablock fxDTSBrickData (brick2x49x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x49x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x49x6";
};

datablock fxDTSBrickData (brick2x50x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x50x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x50x6";
};

datablock fxDTSBrickData (brick2x51x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x51x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x51x6";
};

datablock fxDTSBrickData (brick2x52x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x52x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x52x6";
};

datablock fxDTSBrickData (brick2x53x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x53x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x53x6";
};

datablock fxDTSBrickData (brick2x54x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x54x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x54x6";
};

datablock fxDTSBrickData (brick2x55x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x55x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x55x6";
};

datablock fxDTSBrickData (brick2x56x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x56x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x56x6";
};

datablock fxDTSBrickData (brick2x57x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x57x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x57x6";
};

datablock fxDTSBrickData (brick2x58x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x58x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x58x6";
};

datablock fxDTSBrickData (brick2x59x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x59x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x59x6";
};

datablock fxDTSBrickData (brick2x60x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x60x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x60x6";
};

datablock fxDTSBrickData (brick2x61x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x61x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x61x6";
};

datablock fxDTSBrickData (brick2x62x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x62x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x62x6";
};

datablock fxDTSBrickData (brick2x63x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x63x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x63x6";
};

datablock fxDTSBrickData (brick2x64x6Data)
{
	brickFile = "Add-Ons/GameMode_Renderman_Haunting/bricks/2x64x6.blb";
	category = "Bricks";
	subCategory = "2Higher";
	uiName = "2x64x6";
};
