//$EnvGuiServer::VisibleDistance 300.0
//$EnvGuiServer::FogDistance 1000.0

datablock PlayerData(PlayerFlappyArmor : PlayerStandardArmor)
{
	runForce = 0;
	runEnergyDrain = 0;
	minRunEnergy = 0;
	maxForwardSpeed = 0;
	maxBackwardSpeed = 0;
	maxSideSpeed = 0;
	horizResistFactor = 1.0;

	maxForwardCrouchSpeed = 0;
	maxBackwardCrouchSpeed = 0;
	maxSideCrouchSpeed = 0;
	
	crouchBoundingBox = PlayerStandardArmor.boundingBox; //remove the crouch bounding box
	
	canJet = 0;

	jumpForce = 0;
	jumpEnergyDrain = 0;
	minJumpEnergy = 0;
	jumpDelay = 0;
	
	thirdPersonOnly = 1;
	firstPersonOnly = 0;

	maxLookAngle = 0;
	minLookAngle = 0;
	
	maxSideSpeed = 0;
	
	is2DPlayer = 1;
	cameraDirection2D = 0;
	cameraPitch2D = 0;
	cameraDistance2D = 20;

	minJetEnergy = 0;
	jetEnergyDrain = 0;

	uiName = "Flappy Player";
	showEnergyBar = false;
};

datablock PlayerData(PlayerFlappyCrouchCheatArmor : PlayerFlappyArmor)
{
	crouchBoundingBox = PlayerStandardArmor.crouchBoundingBox;
	
	uiName = "Flappy Player Crouch";
};

//experimental "smooth" flapping. i don't know how well this works on a slow connection so it's not in use.
//function Player::SmoothUp(%obj,%this)
//{
//	//talk("OBJ: " @ %obj);
//	if($FlappyJumpSmoothAllow)
//	{
//		for(%i = 0; %i < %this+1; %i++) 
//		{
//			//schedule(%i*$FlappyJumpSmoothing,0,eval,%obj @ ".addVelocity(\"0 0 -" @ %i @ "\");" @ %obj @ ".addVelocity(\"0 0 " @ %i+1 @ "\");"); 
//			schedule(%i*$FlappyJumpSmoothing,0,eval,%obj @ ".setVelocity(\"" @ getWord(%obj.getVelocity(),0) SPC getWord(%obj.getVelocity(),1) SPC "-" @ %i @ "\");" @ %obj @ ".setVelocity(\"" @ getWord(%obj.getVelocity(),0) SPC getWord(%obj.getVelocity(),1) SPC %i+1 @ "\");"); 
//		}
//		return;
//	}
//	else
//	{
//		%obj.setVelocity(getWords(%obj.getVelocity(),0,1) SPC %this);
//	}
//	
//	//talk("OBJ: " @ %obj);
//	//talk("VEL: " @ %obj.getVelocity());
//	//talk("SET: " @ getWord(%obj.getVelocity(),0) SPC getWord(%obj.getVelocity(),1) SPC %this);
//}

//flap loop
function flapLoop()
{
	if(ClientGroup.getCount() != 0)
	{
		for(%i = 0; %i < ClientGroup.getCount(); %i++) 
		{ 
			%client = clientGroup.getObject(%i); 
			if(isObject(%client.player) && !%client.noFlap && !%client.player.noFlap)
			{
				%client.player.setVelocity($FlappySpeed SPC getWords(%client.player.getVelocity(),1,2));
				//%client.player.addVelocity($FlappySpeed @ " 0 0");
				
				if(getWord(%client.player.getTransform(),2)>$FlappyCheaterHeight)
				{
					messageClient(%client,'MsgFlappyCheater',"CHEATER!");
					//echo(%client.name @ " above maximum height, force-killing...");
					%client.player.kill();
				}
			}
		}
	}
	$FlapLoop = schedule(1000,0,flapLoop);
}

//distance recorder loop
function distLoop()
{
	for(%i=0;%i<ClientGroup.getCount();%i++)
	{ 
		%client = clientGroup.getObject(%i); 
		if(isObject(%client.player) && !%client.noFlap && !%client.player.noFlap) 
		{
			%client.distance = mCeil(getWord(%client.player.getTransform()+%client.player.flappyPosAdd,0)); 
			%id = %client.getblid();
			%viewdistance = %client.distance;
			%highscore = $FlappyHighScorePersonal[%id];
			
			if(%client.distance < 0)
				%viewdistance = 0;
			
			if(!%client.noPrint)
			{
				%client.bottomPrint("<font:impact:50><color:FFFF00><just:left>Score: "@%viewdistance @ "<just:right>Best: " @ %highscore,1,1);
			}
			
			if(isObject(%client.player) && getWord(%client.player.getTransform(),0)>=$FlappyPosEnd)
			{
				%pos1 = getWord(%client.player.getTransform(),0);
				//talk("LOOPING PLAYER: " @ %client.name @ " (" @ %pos1 @ ")");
				%client.player.setTransform(setWord(%client.player.getTransform(),0,$FlappyPosStart));
				%pos2 = getWord(%client.player.getTransform(),0);
				%client.player.flappyPosAdd += %pos1-%pos2;
				//talk("LOOPED PLAYER: " @ %client.name @ "(" @ %pos2 @ ")");
			}
			
			//this should help prevent players from surviving when they hit a pipe (sometimes events don't work for some reason)
			//disabling this because people died in mid-air for no reason (and other misc problems)
			//if(getWord(%client.player.getVelocity(),0) < 9 && %client.distance > 5)
			//{
			//	echo(%client.name SPC %client.player.getVelocity() @ ";" SPC %client.player.position);
			//	//%client.player.kill();
			//	//echo("killed nonmoving player");
			//}
			
			//because of the 2d camera's distance, 3d sounds are quieter (which makes 2d sounds too loud to use)
			
			if(%client.distance > 200 && !%client.player.flappyBronze)
			{
				$FlappyHighScoreBronze[%id] = 1;
				$FlappyHighScoreBronzeCount[%id]++;
				%client.player.flappyBronze = 1;
				%client.centerPrint("<font:impact:40><color:CD7F32>Bronze Medal Awarded",5);
				
				%client.player.emote(winStarProjectile, 1);
				serverPlay3D(rewardSound,%client.player.position); 
			}
			
			if(%client.distance > 400 && !%client.player.flappySilver)
			{
				$FlappyHighScoreSilver[%id] = 1;
				$FlappyHighScoreSilverCount[%id]++;
				%client.player.flappySilver = 1;
				%client.centerPrint("<font:impact:40><color:afafaf>Silver Medal Awarded",5);
				
				%client.player.emote(winStarProjectile, 1);
				serverPlay3D(rewardSound,%client.player.position);
			}
			
			if(%client.distance > 600 && !%client.player.flappyGold)
			{
				$FlappyHighScoreGold[%id] = 1;
				$FlappyHighScoreGoldCount[%id]++;
				%client.player.flappyGold = 1;
				%client.centerPrint("<font:impact:40><color:ffd420>Gold Medal Awarded",5);
				
				%client.player.emote(winStarProjectile, 1);
				serverPlay3D(rewardSound,%client.player.position);
			}
		} 
	}
	
	$distloop = schedule(32,0,distLoop);
}

//export loop
function exportLoop()
{
	if($FlappyHighScoreUpdate) //only export if something changes (to avoid console spam)
	{
		export("$FlappyHighScore*","config/server/FlappyBirdScores.cs");
		echo("Exporting Flappy Bird high scores...");
		$exportLoop = schedule(120000,0,exportLoop);
		$FlappyHighScoreUpdate = 0;
	}
}

//only resets the top ten scores. to reset scores, remove "config/server/FlappyBirdScores.cs"
//function resetFlappyHighScores(%client)
//{
//	if(!%client.isSuperAdmin)
//	{
//		return;
//	}
//	
//	echo(%client.name @ " reset all high scores");
//	messageAll('FlappyReset',%client.name @ " reset all high scores");
//	
//	$FlappyHighScoreUpdate = 1;
//	
//	$FlappyHighScore[1] = 10;
//	$FlappyHighScoreName[1] = "Flappy Bird";
//	$FlappyHighScoreID[1] = 50;
//
//	$FlappyHighScore[2] = 9;
//	$FlappyHighScoreName[2] = "Flappy Bird";
//	$FlappyHighScoreID[2] = 50;
//
//	$FlappyHighScore[3] = 8;
//	$FlappyHighScoreName[3] = "Flappy Bird";
//	$FlappyHighScoreID[3] = 50;
//
//	$FlappyHighScore[4] = 7;
//	$FlappyHighScoreName[4] = "Flappy Bird";
//	$FlappyHighScoreID[4] = 50;
//
//	$FlappyHighScore[5] = 6;
//	$FlappyHighScoreName[5] = "Flappy Bird";
//	$FlappyHighScoreID[5] = 50;
//
//	$FlappyHighScore[6] = 5;
//	$FlappyHighScoreName[6] = "Flappy Bird";
//	$FlappyHighScoreID[6] = 50;
//
//	$FlappyHighScore[7] = 4;
//	$FlappyHighScoreName[7] = "Flappy Bird";
//	$FlappyHighScoreID[7] = 50;
//
//	$FlappyHighScore[8] = 3;
//	$FlappyHighScoreName[8] = "Flappy Bird";
//	$FlappyHighScoreID[8] = 50;
//
//	$FlappyHighScore[9] = 2;
//	$FlappyHighScoreName[9] = "Flappy Bird";
//	$FlappyHighScoreID[9] = 50;
//
//	$FlappyHighScore[10] = 1;
//	$FlappyHighScoreName[10] = "Flappy Bird";
//	$FlappyHighScoreID[10] = 50;
//}

function flap(%player)
{
	if($FlappyJumpControlEnabled || %player.isJumpControlPlayer || %player.dataBlock $= "PlayerFlappyArmor" || %player.dataBlock $= "PlayerFlappyCrouchCheatArmor")
	{
		if($FlappyJumpAirAnim)
		{
			%player.playThread(0,jump);
		}
		//talk("jump " @ %player);
		
		if(!%player.isJumpTimeout)
		{
			%jumpVelocity = getRandom($FlappyJumpVelocity1,$FlappyJumpVelocity2);
			//%player.smoothUp(%jumpVelocity); 
			serverPlay3D(jumpSound,%player.position);
			%player.setVelocity(getWords(%player.getVelocity(),0,1) SPC %jumpVelocity);
			
			//talk("addvelocity " @ %JumpVelocity @ " " @ %player);
		}
		
		cancel(%player.timeout);
		%player.isJumpTimeout = 1;
		
		%timeout = getRandom($FlappyJumpTimeout1,$FlappyJumpTimeout2);
		//talk("timeout " @ %timeout @ " " @ %player);
		//echo("obj.isJumpControlPlayer: " @ %player.isJumpControlPlayer);
		%player.timeout = schedule(%timeout,0,eval,%player @ ".isJumpTimeout = 0; ");
		
		return 1;
	}
}

package GameMode_Flappy_Bird
{
	//flap by jumping (onTrigger slot 2)
	function Armor::onTrigger(%data,%obj,%slot,%val) 
	{
		Parent::onTrigger(%data,%obj,%slot,%val); 
		//%obj = player
		if(%slot == 2 && %val) 
		{
			flap(%obj);
		}
	}
	
	//flap by planting
	function serverCmdPlantBrick(%client)
	{
		if(isObject(%client.player) && !%client.noPlantFlap)
		{
			%flap = flap(%client.player);
			
			if(%flap)
			{
				return;
			}
		}
		Parent::serverCmdPlantBrick(%client); 
	}

	//onDeath
	function GameConnection::onDeath(%client) 
	{
		if($DistLoop==0)
		{
			return parent::onDeath(%client); 
			//return;
		}
		
		$FlappyHighScoreDeaths[%client.bl_id]++;
		
		//echo(%client.name @ " DIED; final score is " @ %client.distance); 
		messageClient(%client,'MsgFlappyBirdDead',"You died! Distance: \c6" @ %client.distance);
		%score = %client.distance;
		%oldScore = $FlappyHighScorePersonal[%client.bl_id];
		
		if(%score > $FlappyHighScorePersonal[%client.bl_id])
		{
			%leaderboard = 1;
			$FlappyHighScorePersonal[%client.bl_id] = %score;
			$FlappyHighScoreUpdate = 1;
			messageClient(%client,'MsgFlappyBirdPersonalScoreWin',"Your new personal record is \c6" @ %score @ "\c0!");
		}
		
		if(%client.bl_id==999999)
		{
			%leaderboard = 1;
		}
		
		//doesn't count if the score isn't above their personal best (lan clients excepted)
		
		//leaderboard check
		if(%score > $FlappyHighScore[20] && %leaderboard)
		{
			//talk("New high score!");
			
			for(%i = 1; %i <= 20; %i++)
			{
				//echo("FOR i" SPC %i);
				//talk(%i);
				if(%score > $FlappyHighScore[%i])
				{
					//talk("Found new position: " @ %i);
					%newpos = %i;
					
					//if they already have a lower slot, we'll remove it and push down scores to fill it.
					if(%client.bl_id != 999999)
					{
						
						//talk("lan check passed");
						for(%iB = 1; %iB <= 20; %iB++)
						{
							//echo("FOR iB" SPC %iB);
							if(%client.getblid() == $FlappyHighScoreID[%iB])
							{
								if(%emptySlot)
								{
									error("Flappy Bird - Multiple empty slots! First slot will be filled. (i: " @ %i @ "; iB: " @ %iB @ "; newpos: " @ %newpos @ "; emptyslot: " @ %emptyslot @ "; score: " @ %score @ "; player: " @ %client.bl_id SPC %client.name @ ")");
									break;
								}
								else
								{
									//talk("Player already has a leaderboard spot! Removing it...");
									//echo("REMOVING EXISTING SCORE");
									
									%emptySlot = %iB; //empty slot will be filled
									$FlappyHighScoreName[%iB] = "\c5This slot should be filled!";
								}
							}
						}
					}
					
					if(!%emptySlot)
					{
						%emptySlot = 20;
					}
					
					if(%emptyslot == %newpos)
					{
						//talk("New slot is same as the old, filling...");
						//echo("filling score #" @ %newpos @ " with the new values (" @ %client.name @ ", " @ %client.bl_id @ ", " @ %score @ ")");
						
						if(%newpos <= 10) //leaderboard scores above 10 are recorded but hidden (for now)
						{
							messageClient(%client,'',"Congratulations, your score is \c6#" @ %newpos @ "\c0 on the leaderboard! Type /leaderboard to view it.");
						}
						
						$FlappyHighScore[%newpos] = %score;
						$FlappyHighScoreName[%newpos] = %client.name;
						$FlappyHighScoreID[%newpos] = %client.bl_id;
						
						if(%client.bl_id==999999)
						{
							$FlappyHighScoreID[%newpos] = "LAN";
						}
						
						$FlappyHighScoreUpdate = 1;
						break;
					}
					
					if(%emptySlot < %newpos)
					{
						error("Flappy Bird - Empty slot < new position! (i: " @ %i @ "; iB: " @ %iB @ "; newpos: " @ %newpos @ "; emptyslot: " @ %emptyslot @ "; score: " @ %score @ "; player: " @ %client.bl_id SPC %client.name @ ")");
					}
					
					//%emptySlot is the slot to be filled. %emptySlot-1 is the last slot to be pushed down.
					
					//echo("slot " @ %emptySlot @ " is now empty and will be filled");
					//echo("for(%iC = %emptySlot-1; %iC >= %newpos; %iC--)");
					//echo("for(%iC = " @ %emptySlot-1 @ "; %iC >= " @ %newpos @ "; %iC--");
					for(%iC = %emptySlot-1; %iC >= %newpos; %iC--)
					{
						//echo("FOR iC" SPC %iC);
						//echo("bumping DOWN score #" @ %iC @ " to #" @ %iC+1 @ " (Score: " @ $FlappyHighScore[%iC] @ "; Name: " @ $FlappyHighScoreName[%iC] @ ")");
						$FlappyHighScore[%iC+1] = $FlappyHighScore[%iC];
						$FlappyHighScoreName[%iC+1] = $FlappyHighScoreName[%iC];
						$FlappyHighScoreID[%iC+1] = $FlappyHighScoreID[%iC];
						//$FlappyHighScoreUpdate = 1;
						
						if(%iC == %newpos)
						{
							//echo("filling score #" @ %newpos @ " with the new values (" @ %client.name @ ", " @ %client.bl_id @ ", " @ %score @ ")");
							
							if(%newpos <= 10) //leaderboard scores above 10 are recorded but hidden (for now)
							{
								messageClient(%client,'',"Congratulations! Your score is \c6#" @ %newpos @ "\c0 on the leaderboard!");
							}
							
							$FlappyHighScore[%newpos] = %score;
							$FlappyHighScoreName[%newpos] = %client.name;
							$FlappyHighScoreID[%newpos] = %client.bl_id;
							
							if(%client.bl_id==999999)
							{
								$FlappyHighScoreID[%newpos] = "LAN";
							}
						}
					}
					$FlappyHighScoreUpdate = 1;
					break;
				}
			}
		}
		%client.score = $FlappyHighScorePersonal[%client.bl_id];
		parent::onDeath(%client); 
	}

	////CLEANUP////
	function destroyServer()
	{
		echo("Exporting Flappy Bird high scores (server closing)");
		
		export("$FlappyHighScore*","config/server/FlappyBirdScores.cs");
		deleteVariables("$Flappy*");
		cancel($exportLoop);
		cancel($flapLoop);
		cancel($distLoop);
		parent::destroyServer();
	}

	////CLEANUP////
	function onExit()
	{		
		echo("Exporting Flappy Bird high scores (server closing/quit)");
		
		export("$FlappyHighScore*","config/server/FlappyBirdScores.cs");
		deleteVariables("$Flappy*");
		cancel($exportLoop);
		cancel($flapLoop);
		cancel($distLoop);
		
		parent::onExit();
	}
	
	////prevent admin cheaters////
	function serverCmdDropCameraAtPlayer(%client)
	{
		%client.player.noFlap = 1;
		Parent::ServerCmdDropCameraAtPlayer(%client);
	}
	function serverCmdDropPlayerAtCamera(%client)
	{
		%client.player.noFlap = 1;
		Parent::serverCmdDropPlayerAtCamera(%client);
	}
	function serverCmdWarp(%client) //broken?
	{
		%client.player.noFlap = 1;
		Parent::serverCmdWarp(%client);
	}
	function serverCmdFetch(%client,%this)
	{
		if(!$FlappyNoFetch)
		{
			Parent::serverCmdFetch(%client,%this);
		}
	}
	
	//ToggleJC
	function serverCmdToggleJC(%client)
	{
		if(%client.isSuperAdmin)
		{
			if($FlappyJumpControlEnabled)
			{
				$FlappyJumpControlEnabled = 0;
				messageAll('MsgJumpControl',%client.name @ " disabled global jump control");
				return;
			}			
			
			if(!$FlappyJumpControlEnabled)
			{
				$FlappyJumpControlEnabled = 1;
				messageAll('MsgJumpControl',%client.name @ " enabled global jump control");
			}
		}
	}

	//SetJCVelocity
	function serverCmdSetJCVelocity(%client,%val1,%val2)
	{
		if(%client.isAdmin)
		{
			if(!%val1 || !%val2)
			{
				%output1 = 8;
				%output2 = 12;
			}
			else
			{
				%output1 = %val1;
				%output2 = %val2;
			}
			
			$FlappyJumpVelocity1 = %output1;
			$FlappyJumpVelocity2 = %output2;
			
			messageAll('MsgJumpControl',%client.name @ " changed the jump velocity to (" @ %output1 @ "," @ %output2 @ ")");
		}
	}

	//SetJCTimeout
	function serverCmdSetJCTimeout(%client,%val1,%val2)
	{
		if(%client.isAdmin)
		{
			if(!%val1 || !%val2)
			{
				%output1 = 500;
				%output2 = 750;
			}
			else
			{
				%output1 = %val1;
				%output2 = %val2;
			}
			
			$FlappyJumpTimeout1 = %output1;
			$FlappyJumpTimeout2 = %output2;
			
			messageAll('MsgJumpControl',%client.name @ " changed the jump timeout to (" @ %output1 @ "," @ %output2 @ ")");
		}
	}

	//SetJCSmoothing
	function serverCmdSetJCSmoothing(%client,%this)
	{
		if(%client.isAdmin)
		{
			if(!%this || %this > 50 || %this < 0)
			{
				%output = 1;
			}
			else
			{
				%output = %this;
			}
			
			$FlappyJumpSmoothing = %output;
			
			messageAll('MsgJumpControl',%client.name @ " changed the jump smoothing to " @ %output);
		}
	}

	function serverCmdToggleFlapLoop(%client)
	{
		if(!%client.isSuperAdmin)
		{
			return;
		}
		
		if(!$FlapLoop)
		{
			echo("Flap loop enabled by " @ %client.name);
			messageAll('MsgFlapLoopEnable',%client.name @ " enabled the flap loop");
			flapLoop();
		}
		else
		{
			echo("Flap loop disabled by " @ %client.name);
			messageAll('MsgFlapLoopDisable',%client.name @ " disabled the flap loop");
			cancel($FlapLoop);
			$FlapLoop = 0;
		}
	}

	function serverCmdToggleDistLoop(%client)
	{
		if(!%client.isSuperAdmin)
		{
			return;
		}
		
		if(!$DistLoop)
		{
			echo("Distance loop enabled by " @ %client.name);
			messageAll('MsgDistLoopEnable',%client.name @ " enabled the distance loop");
			distLoop();
		}
		else
		{
			echo("Distance loop disabled by " @ %client.name);
			messageAll('MsgDistLoopDisable',%client.name @ " disabled the distance loop");
			cancel($DistLoop);
			$DistLoop = 0;
		}
	}

	function serverCmdSetFlappyDefaults(%client)
	{
		if(!%client.isSuperAdmin)
		{
			return;
		}

		echo(%client.name SPC "is resetting the default settings for Flappy Bird...");
		messageAll('MsgFlappyReset',%client.name SPC "is resetting the default settings for Flappy Bird...");
		
		$FlappyJumpVelocity1 = 9.85;
		$FlappyJumpVelocity2 = 9.85;

		$FlappyJumpTimeout1 = 1;
		$FlappyJumpTimeout2 = 1;

		$FlappyJumpSmoothing = 1;
		$FlappyJumpSmoothAllow = 0;

		$FlappyJumpAirAnim = 1;

		//old
		//$FlappyPosStart = 334.75; 
		//$FlappyPosEnd = 590.75;
		
		$FlappyPosStart = 95.75;
		$FlappyPosEnd = 831.75;

		$FlappyCheaterHeight = 90;

		$FlappySpeed = 10;
	}

	function serverCmdSetFlappySpeed(%client,%speed)
	{
		if(!%client.isSuperAdmin)
		{
			return;
		}
		
		if(%speed < 1 || %speed > 100 || !%speed)
		{
			$FlappySpeed = 10;
			echo(%client.name @ " changed the flap speed to 10");
			messageAll('MsgFlapSpeed',%client.name @ " changed the flap speed to 10");
			return;
		}

		$FlappySpeed = %speed;
		echo(%client.name @ " changed the flap speed to " @ %speed);
		messageAll('MsgFlapSpeed',%client.name @ " changed the flap speed to " @ %speed);
	}

	function serverCmdSetFlappyCheaterHeight(%client,%height)
	{
		if(!%client.isSuperAdmin)
		{
			return;
		}
		
		if(%height < 0 || !%height)
		{
			$FlappyCheaterHeight = 90;
			echo(%client.name @ " changed the flap height to 90");
			messageAll('MsgFlapHeight',%client.name @ " changed the flap height to 90");
			return;
		}

		$FlappyCheaterHeight = %height;
		echo(%client.name @ " changed the flap height to " @ %height);
		messageAll('MsgFlapHeight',%client.name @ " changed the flap height to " @ %height);
	}

	function serverCmdResetFlapLoop(%client)
	{
		if(!%client.isSuperAdmin)
		{
			return;
		}
		
		cancel($FlapLoop);
		flapLoop();
		
		echo(%client.name @ " reset the flap loop");
	}

	function serverCmdHighScores(%client)
	{
		//messageClient(%client,'FlappyHighScoreListStart',"\c2 # \c7|\c2 Score \c7|\c2 BL ID \c7|\c2 Name");
		//messageClient(%client,'FlappyHighScore10',"\c0#:\c6 10 \c7|\c0 Distance:\c6 1572 \c7|\c0 ID:\c6 123456 \c7|\c0 Name:\c6 RandomPlayerlol123");
		messageClient(%client,'FlappyHighScore10',"\c0#:\c6 10 \c7|\c0 Distance:\c6 " @ $FlappyHighScore[10] @ " \c7|\c0 ID:\c6 " @ $FlappyHighScoreID[10] @ " \c7|\c0 Name:\c6 " @ $FlappyHighScoreName[10]);
		messageClient(%client,'FlappyHighScore9',"\c0#:\c6 9 \c7|\c0 Distance:\c6 " @ $FlappyHighScore[9] @ " \c7|\c0 ID:\c6 " @ $FlappyHighScoreID[9] @ " \c7|\c0 Name:\c6 " @ $FlappyHighScoreName[9]);
		messageClient(%client,'FlappyHighScore8',"\c0#:\c6 8 \c7|\c0 Distance:\c6 " @ $FlappyHighScore[8] @ " \c7|\c0 ID:\c6 " @ $FlappyHighScoreID[8] @ " \c7|\c0 Name:\c6 " @ $FlappyHighScoreName[8]);
		messageClient(%client,'FlappyHighScore7',"\c0#:\c6 7 \c7|\c0 Distance:\c6 " @ $FlappyHighScore[7] @ " \c7|\c0 ID:\c6 " @ $FlappyHighScoreID[7] @ " \c7|\c0 Name:\c6 " @ $FlappyHighScoreName[7]);
		messageClient(%client,'FlappyHighScore6',"\c0#:\c6 6 \c7|\c0 Distance:\c6 " @ $FlappyHighScore[6] @ " \c7|\c0 ID:\c6 " @ $FlappyHighScoreID[6] @ " \c7|\c0 Name:\c6 " @ $FlappyHighScoreName[6]);
		messageClient(%client,'FlappyHighScore5',"\c0#:\c6 5 \c7|\c0 Distance:\c6 " @ $FlappyHighScore[5] @ " \c7|\c0 ID:\c6 " @ $FlappyHighScoreID[5] @ " \c7|\c0 Name:\c6 " @ $FlappyHighScoreName[5]);
		messageClient(%client,'FlappyHighScore4',"\c0#:\c6 4 \c7|\c0 Distance:\c6 " @ $FlappyHighScore[4] @ " \c7|\c0 ID:\c6 " @ $FlappyHighScoreID[4] @ " \c7|\c0 Name:\c6 " @ $FlappyHighScoreName[4]);
		messageClient(%client,'FlappyHighScore3',"\c0#:\c6 3 \c7|\c0 Distance:\c6 " @ $FlappyHighScore[3] @ " \c7|\c0 ID:\c6 " @ $FlappyHighScoreID[3] @ " \c7|\c0 Name:\c6 " @ $FlappyHighScoreName[3]);
		messageClient(%client,'FlappyHighScore2',"\c0#:\c6 2 \c7|\c0 Distance:\c6 " @ $FlappyHighScore[2] @ " \c7|\c0 ID:\c6 " @ $FlappyHighScoreID[2] @ " \c7|\c0 Name:\c6 " @ $FlappyHighScoreName[2]);
		messageClient(%client,'FlappyHighScore1',"\c0#:\c6 1 \c7|\c0 Distance:\c6 " @ $FlappyHighScore[1] @ " \c7|\c0 ID:\c6 " @ $FlappyHighScoreID[1] @ " \c7|\c0 Name:\c6 " @ $FlappyHighScoreName[1]);
		messageClient(%client,'FlappyHighScoreEnd',"Press PageUp to see more. Tip: You can also see high scores in the player list!");
	}
	
	function serverCmdLeaderboard(%client)
	{
		serverCmdHighScores(%client);
	}

	function serverCmdStats(%client)
	{
		%id = %client.bl_id;
		
		if($FlappyHighScoreBronzeCount[%id] == 1)
			%bronzeWord = "medal";
		else
			%bronzeWord = "medals";
		
		if($FlappyHighScoreSilverCount[%id] == 1)
			%silverWord = "medal";
		else
			%silverWord = "medals";
		
		if($FlappyHighScoreGoldCount[%id] == 1)
			%goldWord = "medal";
		else
			%goldWord = "medals";
		
		messageClient(%client,'FlappyStats',"\c0Your high score is \c6" @ $FlappyHighScorePersonal[%id] @ "\c0. You've died \c6" @ $FlappyHighScoreDeaths[%id] @ "\c0 times!");
		messageClient(%client,'FlappyStats',"\c0You have earned \c6" @ $FlappyHighScoreBronzeCount[%id] @ "\c0 bronze " @ %bronzeWord @ ", \c6" @ $FlappyHighScoreSilverCount[%id] @ "\c0 silver " @ %silverWord @ ", and \c6" @ $FlappyHighScoreGoldCount[%id] @ "\c0 gold " @ %goldWord @ ".");
		messageClient(%client,'FlappyStats',"\c0You can view the server's top scores by typing \c6/leaderboard");
	}
	
	function serverCmdMyHighScore(%client)
	{
		serverCmdStats(%client);
	}
	
	//give people the download links when they join
	function GameConnection::autoAdminCheck(%client)
	{
		%id = %client.bl_id;
		//initialize their high score variables (this is necessary)
		if(!$FlappyHighScorePersonal[%id])
			$FlappyHighScorePersonal[%id] = 0;
		
		if(!$FlappyHighScoreDeaths[%id])
			$FlappyHighScoreDeaths[%id] = 0;
		
		if(!$FlappyHighScoreBronzeCount[%id])
			$FlappyHighScoreBronzeCount[%id] = 0;
		
		if(!$FlappyHighScoreSilverCount[%id])
			$FlappyHighScoreSilverCount[%id] = 0;
		
		if(!$FlappyHighScoreGoldCount[%id])
			$FlappyHighScoreGoldCount[%id] = 0;
		
		//add medals to their count if they earned them previously
		if($FlappyHighScoreBronze[%id] && !$FlappyHighScoreBronzeCount[%id])
			$FlappyHighScoreBronzeCount[%id] = 1;
		
		if($FlappyHighScoreSilver[%id] && !$FlappyHighScoreSilverCount[%id])
			$FlappyHighScoreSilverCount[%id] = 1;
		
		if($FlappyHighScoreGold[%id] && !$FlappyHighScoreGoldCount[%id])
			$FlappyHighScoreGoldCount[%id] = 1;
		
		//check for a leaderboard name update
		for(%i = 1; %i < 11; %i++)
		{
			//echo($FlappyHighScoreID[%i] SPC %client.getblid());
			if(%id == $FlappyHighScoreID[%i] && %client.name !$= $FlappyHighScoreName[%i])
			{
				echo("Updated leaderboard name" SPC $FlappyHighScoreName[%i] SPC "to" SPC %client.name);
				$FlappyHighScoreName[%i] = %client.name;
			}
		}
		
		Parent::autoAdminCheck(%client);
	}
};

schedule(120000,0,exportloop);
deactivatePackage("GameMode_Flappy_Bird");
activatePackage("GameMode_Flappy_Bird");

//jump control defaults
$FlappyJumpVelocity1 = 9.85;
$FlappyJumpVelocity2 = 9.85;

$FlappyJumpTimeout1 = 1;
$FlappyJumpTimeout2 = 1;

$FlappyJumpSmoothing = 1;
$FlappyJumpSmoothAllow = 0;

$FlappyJumpAirAnim = 1;

//old
//$FlappyPosStart = 334.75; 
//$FlappyPosEnd = 590.75;

$FlappyPosStart = 95.75;
$FlappyPosEnd = 831.75;

$FlappyCheaterHeight = 90;

$FlappySpeed = 10;

if($GameModeArg !$= "Add-Ons/GameMode_Flappy_Bird/gamemode.txt")
{
	//$FlappyJumpControlEnabled = 0;
}
else
{
	if(isFile("Add-Ons/Brick_WedgePlus.zip"))
	{
		exec("Add-Ons/Brick_WedgePlus/server.cs");
	}

	flapLoop();
	distLoop();

	$FlappyNoFetch = 1;
	//$FlappyJumpControlEnabled = 1;
}

function flappyResetLeaderboard()
{
	for(%i = 1; %i <= 20; %i++)
	{
		//echo("Adding temporary score SLOT: " @ %i @ "; SCORE: " @ -%i+21);
		
		$FlappyHighScore[%i] = -%i+21;
		$FlappyHighScoreName[%i] = "Flappy Bird";
		$FlappyHighScoreID[%i] = 50;
	}
}

if(!$FlappyLoaded)
{
	if(!isFile("config/server/FlappyBirdScores.cs"))
	{
		
		for(%i = 1; %i <= 20; %i++)
		{
			//echo("Adding temporary score SLOT: " @ %i @ "; SCORE: " @ -%i+21);
			
			$FlappyHighScore[%i] = -%i+21;
			$FlappyHighScoreName[%i] = "Flappy Bird";
			$FlappyHighScoreID[%i] = 50;
		}
		
		echo("Exporting Flappy Bird high scores...");
		export("$FlappyHighScore*","config/server/FlappyBirdScores.cs");

	}
	else
	{
		exec("config/server/FlappyBirdScores.cs");
		$flappyLoaded = 1;
	}
}
//else
//{
//	echo("already load scores");
//}