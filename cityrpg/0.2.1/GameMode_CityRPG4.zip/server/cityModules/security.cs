function serverCmdLootDrugs(%client) {
	%client.cityLog("Exploit attempt /lootDrugs", 0, 1);
}

function serverCmdeSet(%client) {
	%client.cityLog("Exploit attempt /eSet", 0, 1);
}

function serverCmdrt(%client) {
	%client.cityLog("Exploit attempt /rt", 0, 1);
}

function serverCmdfit(%client) {
	%client.cityLog("Exploit attempt /fit", 0, 1);
}
