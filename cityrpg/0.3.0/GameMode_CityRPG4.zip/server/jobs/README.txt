This is the directory for CityRPG jobs. These jobs are loaded into the game-mode via server/jobs.cs.

The outfit order is as follows:
accent hat pack secondPack chest arms gloves hip feet facedecal chestdecal

For global job tree options, see "jobTrees.cs" in the server/ folder.
