This is the directory for CityRPG jobs. Each job is associated with an ID that is specified at the top of scriptobject.cs

Beware that the existing job system is deprecated. There are plans to replace it entirely in the future.

The outfit order is as follows:
accent hat pack secondPack chest arms gloves hip feet facedecal chestdecal
