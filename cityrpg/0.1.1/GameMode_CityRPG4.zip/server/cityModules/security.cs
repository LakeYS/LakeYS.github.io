function serverCmdLootDrugs(%client) {
	%client.cityLog("!!!EXPLOIT ATTEMPT!!! /lootDrugs");
}

function serverCmdeSet(%client) {
	%client.cityLog("!!!EXPLOIT ATTEMPT!!! /eSet");
}

function serverCmdrt(%client) {
	%client.cityLog("!!!EXPLOIT ATTEMPT!!! /rt");
}

function serverCmdfit(%client) {
	%client.cityLog("!!!EXPLOIT ATTEMPT!!! /fit");
}
