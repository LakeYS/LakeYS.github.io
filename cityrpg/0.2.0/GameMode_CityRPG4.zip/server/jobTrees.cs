$City::JobTrackColor["Labor"] = "828282";
$City::JobTrackColor["Business"] = "00A648";
$City::JobTrackColor["Bounty Hunter"] = "C41700";
$City::JobTrackColor["Police"] = "4976FD";
$City::JobTrackColor["Government"] = "4A5096";
