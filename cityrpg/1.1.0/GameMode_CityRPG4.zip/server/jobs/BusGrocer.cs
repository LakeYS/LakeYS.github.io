$CityRPG::jobs::name = "Grocer";
$CityRPG::jobs::track = "Business";
$CityRPG::jobs::initialInvestment = 25;
$CityRPG::jobs::pay = 30;
$CityRPG::jobs::tools = "";
$CityRPG::jobs::datablock = Player9SlotPlayer;
$CityRPG::jobs::education = 1;
$CityRPG::jobs::promotions = "BusOwner	BusArmsDealer";

$CityRPG::jobs::sellItems = false;
$CityRPG::jobs::sellFood = true;
$CityRPG::jobs::sellServices = false;

$CityRPG::jobs::law = false;
$CityRPG::jobs::canPardon = false;

$CityRPG::jobs::thief = false;
$CityRPG::jobs::hideJobName = false;

$CityRPG::jobs::offerer = false;
$CityRPG::jobs::claimer = false;

$CityRPG::jobs::labor = false;

$CityRPG::jobs::helpline = "\c6Grocers can open stores and sell food for profit.";

$CityRPG::jobs::outfit = "none none none none greenShirt blackShirt skin blackPants blackShoes default worm-sweater";
