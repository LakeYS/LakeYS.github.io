$CityRPG::jobs::name = "Mayor";
$CityRPG::jobs::track = "Government";
$CityRPG::jobs::title = "Mayor";
$CityRPG::jobs::initialInvestment = 0;
$CityRPG::jobs::pay = 150;
$CityRPG::jobs::tools = "";
$CityRPG::jobs::datablock = Player9SlotPlayer;
$CityRPG::jobs::education = 0;
$CityRPG::jobs::adminonly = 1;

$CityRPG::jobs::sellRestrictedItemsLevel = 2;
$CityRPG::jobs::sellFood = true;
$CityRPG::jobs::sellServices = true;

$CityRPG::jobs::law = false;
$CityRPG::jobs::usepolicecars = true;
$CityRPG::jobs::useparacars = true;
$CityRPG::jobs::canPardon = true;

$CityRPG::jobs::thief = false;
$CityRPG::jobs::hideJobName = true;

$CityRPG::jobs::offerer = true;
$CityRPG::jobs::claimer = true;

$CityRPG::jobs::labor = false;

$CityRPG::jobs::helpline = "\c6The mayor of the city. Makes a handsome salary and governs the people.";
$CityRPG::jobs::flavortext = "Thaaaaaat's politics!";

$CityRPG::jobs::outfit = "none none none none blueShirt blueShirt skin blackPants brownShoes BrownSmiley Mod-Suit";
