$CityRPG::jobs::name = "Civilian";
$CityRPG::jobs::track = "Labor";
$CityRPG::jobs::initialInvestment = 0;
$CityRPG::jobs::pay = 25;
$CityRPG::jobs::tools = "";
$CityRPG::jobs::datablock = Player9SlotPlayer;
$CityRPG::jobs::education = 0;
$CityRPG::jobs::promotions = "LaborMiner	LaborLumberjack";

$CityRPG::jobs::sellRestrictedItemsLevel = 0;
$CityRPG::jobs::sellFood = false;
$CityRPG::jobs::sellServices = false;

$CityRPG::jobs::law = false;
$CityRPG::jobs::canPardon = false;

$CityRPG::jobs::thief = false;
$CityRPG::jobs::hideJobName = false;

$CityRPG::jobs::offerer = false;
$CityRPG::jobs::claimer = false;

$CityRPG::jobs::labor = false;

$CityRPG::jobs::helpline = "\c6Civilians are new to the city. They have no perks or prospects and only collect a small check.";

$CityRPG::jobs::outfit = "none none none none blackShirt blackShirt skin bluePants brownShoes default worm-sweater";
