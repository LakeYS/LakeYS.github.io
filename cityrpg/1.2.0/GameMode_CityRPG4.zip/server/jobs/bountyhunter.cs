$CityRPG::jobs::name = "Bounty Hunter";
$CityRPG::jobs::track = "Bounty Hunter";
$CityRPG::jobs::initialInvestment = 50;
$CityRPG::jobs::pay = 25;
$CityRPG::jobs::tools = "CityRPGLBItem";
$CityRPG::jobs::datablock = Player9SlotPlayer;
$CityRPG::jobs::education = 1;
$CityRPG::jobs::promotions = "BountyVigilante";

$CityRPG::jobs::sellRestrictedItemsLevel = 0;
$CityRPG::jobs::sellFood = false;
$CityRPG::jobs::sellServices = false;

$CityRPG::jobs::law = false;
$CityRPG::jobs::canPardon = false;

$CityRPG::jobs::thief = false;
$CityRPG::jobs::hideJobName = false;

$CityRPG::jobs::offerer = false;
$CityRPG::jobs::claimer = true;

$CityRPG::jobs::labor = false;

$CityRPG::jobs::helpline = "\c6Bounty Hunters can arrest criminals and claim bounties, but don't need a good record.";

$CityRPG::jobs::outfit = "none none none none blackShirt blackShirt skin blackPants blackShoes smileyEvil1 Alyx";
