$CityRPG::jobs::name = "Store CEO";
$CityRPG::jobs::track = "Business";
$CityRPG::jobs::initialInvestment = 125;
$CityRPG::jobs::pay = 90;
$CityRPG::jobs::tools = "";
$CityRPG::jobs::datablock = Player9SlotPlayer;
$CityRPG::jobs::education = 8;

$CityRPG::jobs::sellRestrictedItemsLevel = 2;
$CityRPG::jobs::sellFood = true;
$CityRPG::jobs::sellServices = false;
$CityRPG::jobs::sellClothes = true;

$CityRPG::jobs::law = false;
$CityRPG::jobs::canPardon = false;

$CityRPG::jobs::thief = false;
$CityRPG::jobs::hideJobName = false;

$CityRPG::jobs::offerer = false;
$CityRPG::jobs::claimer = false;

$CityRPG::jobs::labor = false;

$CityRPG::jobs::helpline = "\c6The most highly successful businessmen with strong backgrounds in their business ventures";
$CityRPG::jobs::flavortext = "This guy's so rich, he has a swimming pool in his swimming pool.";

$CityRPG::jobs::outfit = "none none none none whitet whitet skin blackPants blackShoes Male07Smiley Mod-Suit";
