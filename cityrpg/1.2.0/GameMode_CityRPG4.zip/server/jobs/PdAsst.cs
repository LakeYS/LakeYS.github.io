$CityRPG::jobs::name = "Police Assistant";
$CityRPG::jobs::track = "Police";
$CityRPG::jobs::initialInvestment = 25;
$CityRPG::jobs::pay = 30;
$CityRPG::jobs::tools = "CityRPGBatonItem taserItem DoughnutItem";
$CityRPG::jobs::datablock = Player9SlotPlayer;
$CityRPG::jobs::education = 1;
$CityRPG::jobs::promotions = "PdOfficer";

$CityRPG::jobs::sellRestrictedItemsLevel = 0;
$CityRPG::jobs::sellFood = false;
$CityRPG::jobs::sellServices = false;

$CityRPG::jobs::law = true;
$CityRPG::jobs::usepolicecars = true;
$CityRPG::jobs::canPardon = false;

$CityRPG::jobs::thief = false;
$CityRPG::jobs::hideJobName = false;

$CityRPG::jobs::offerer = true;
$CityRPG::jobs::claimer = true;

$CityRPG::jobs::labor = false;

$CityRPG::jobs::helpline = "\c6Assistants to the police department. Carries out lower level operations in the department.";

$CityRPG::jobs::outfit = "none copHat none none copShirt copShirt skin blackPants blackShoes default worm-sweater";
