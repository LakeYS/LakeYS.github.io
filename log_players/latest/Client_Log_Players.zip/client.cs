$IDLogger::DisableEcho = 0;

package IDLogger
{
	function secureClientCmd_ClientJoin(%name,%num,%id,%a,%b,%c,%d)
	{
		Parent::secureClientCmd_ClientJoin(%name,%num,%id,%a,%b,%c,%d);
		if(isFunction(IDLogger_LogID))
		{
			IDLogger_LogID(%name,%id);
		}
	}
	
	function disconnect(%a)
	{
		if(!$IDLogger::NoExport)
		{
			IDLogger_Export();
		}
		
		Parent::disconnect(%a);
	}
};

if($IDLogger)
	deactivatePackage("IDLogger");

activatePackage("IDLogger");
$IDLogger = 1;

function IDLogger_Init()
{
	$IDLogger::TotalSessionIDs = 0;
	%file = new fileobject();
	
	if(isFile("config/client/logs/idlog/HighestID.log"))
	{
		%file.openForRead("config/client/logs/idlog/HighestID.log");
		$IDLogger::HighestID = %file.readline();
		echo("The highest logged ID is" SPC $IDLogger::HighestID @ "!");
		%file.close();
	}
	else
	{
		warn("No highest ID file, setting to 0...");
		$IDLogger::HighestID = 0;
	}
	
	if(isFile("config/client/idlog/HighestID.log") || getFileCount("config/client/idlog/ids/*") > 0) // Because everything was moved from config/idlog to config/logs/idlog
		error("There are files in the old idlog folder. Please move these to the new folder (config/client/logs/idlog)");
	
	%file.delete();
}

//IDLogger_LogID(Name, BLID, Date)
//If a date is specified, the ID is treated as a "Manual Entry" and will be ignored if it already exists.
//Playtime also won't be logged if a date is specified.
function IDLogger_LogID(%name,%id,%date)
{
	if(!$IDLogger::DisableEcho)
	{
		echo("ID Logger - Registering name \"" @ %name @ "\" to id " @ %id);
	}
	
	if(%date && isFile("config/client/logs/idlog/ids/" @ %id @ ".log"))
	{
		echo("ID Logger - Manual entry ID already exists, ignoring...");
		$IDLogger::ManualIDs++;
		return;
	}
	
	if(%id == 999999)
	{
		if(!$IDLogger::DisableEcho)
		{
			echo("ID Logger - LAN ID, ignoring...");
		}
		return;
	}
	
	if(%id >= 300000) //if ids actually get this high i guess i'll just have to update
	{
		if(!$IDLogger::DisableEcho)
		{	
			echo("INVALID ID: " @ %id);
			echo("ID Logger - ID is above 300k, ignoring...");
		}
		return; 
	}
	
	if(%id < 0) //if a mysterious broken id is found
	{
		if(!$IDLogger::DisableEcho)
		{
			echo("INVALID ID: " @ %id);
			echo("ID Logger - ID is < 0 or NaN, ignoring...");
		}
		return;
	}
	
	if(!$IDLogger::SessionID[%id])
	{
		//echo("This is a new session ID!");
		
		$IDLogger::TotalSessionIDs++;
		%SessionID = $IDLogger::TotalSessionIDs;
		
		$IDLogger::SessionID[%id] = %SessionID;
		
		//name logging stuff
		$IDLogger::NameChanges[%SessionID]++;
		
		//NAME
		$IDLogger::NameChange[ %SessionID @ "num" @ $IDLogger::NameChanges[%SessionID] ] = %name; //$IDLogger::NameChange[SessID]num[Count]
		
		//NAME DATE
		$IDLogger::NameChangeDate[ %SessionID @ "num" @ $IDLogger::NameChanges[%SessionID] ] = getDateTime(); //$IDLogger::NameChangeDate[SessID]num[Count]
	}
	else
	{
		//echo("This is an existing session ID!");
		%SessionID = $IDLogger::SessionID[%id]; 
		
		//name logging stuff
		%oldname = $IDLogger::NameChange[ %SessionID @ "num" @ $IDLogger::NameChanges[%SessionID] ];
		//echo("Old name: " @ %oldname);
		if(%name !$= %oldname)
		{
			//echo("New name " @ $IDLogger::NameChanges[%SessionID]+1 @ "! (" @ %oldname @ " !$= " @ %name @ ")");
			$IDLogger::NameChanges[%SessionID]++;
			
			//NAME
			$IDLogger::NameChange[ %SessionID @ "num" @ $IDLogger::NameChanges[%SessionID] ] = %name; //$IDLogger::NameChange[SessID]num[Count]
			
			//NAME DATE
			$IDLogger::NameChangeDate[ %SessionID @ "num" @ $IDLogger::NameChanges[%SessionID] ] = getDateTime(); //$IDLogger::NameChangeDate[SessID]num[Count]
			//echo("Setting $IDLogger::NameChangeDate[" @ %sessionID @ "]num[" @ $IDLogger::NameChanges[%sessionID] @ "] to " @ getDateTime());
		}
	}
	
	if(%id > $IDLogger::HighestID)
	{
		if(!$IDLogger::DisableEcho)
		{
			echo("Highest ID updated! (" @ %id @ " > " @ $IDLogger::HighestID @ ")");
		}
		$IDLogger::HighestID = %id;
	}
	
	$IDLogger::Name[%SessionID] = %name;
	$IDLogger::ID[%SessionID] = %id;
	
	if(!%date)
	{
		$IDLogger::Seen[%SessionID] = getDateTime();
	}
	else
	{
		//echo("Using manual date for this ID (" @ %date @ ")");
		$IDLogger::Seen[%SessionID] = %date;
		//set this up with playtime logging too
	}
	
	$IDLogger::GetBLID[%SessionID] = %id;
	$IDLogger::GetNameByBLID[%id] = %name;
}

function IDLogger_Export()
{
	//fileDelete("config/client/logs/idlog/HighestID.log");
	//fileDelete("config/client/logs/idlog/TotalIDs.log");
	//not needed, openForWrite already overwrites the contents
	
	echo("Exporting ID log");
	%file = new FileObject();
	%file.openForWrite("config/client/logs/idlog/HighestID.log");
	%file.writeLine($IDLogger::HighestID);
	%file.close();
	
	//echo("for(%i = 1; %i <= " @ $IDLogger::TotalSessionIDs @ "; %i++;)");
	for(%i = 1; %i <= $IDLogger::TotalSessionIDs; %i++)
	{
		//echo("Exporting another ID!");
		//echo("Session ID = " @ %i);
		
		$IDLogger::IDsExported++;
		$IDLogger::IDsExportedTotal++;
	
		%ID = $IDLogger::ID[%i];
		%Name = $IDLogger::Name[%i];
		%Seen = $IDLogger::Seen[$IDLogger::TotalSessionIDs];
		
		//echo("ID=" @ %ID SPC "Name=" @ %Name SPC "Seen=" @ %Seen);
		
		//name logging stuff
		if(isFile("config/client/logs/idlog/names/" @ %id @ ".log")) 
		{
			%file.openForRead("config/client/logs/idlog/names/" @ %id @ ".log");
			
			%isNameLine = 0; // IMPORTANT: First line is a date.
			while(!%file.isEOF())
			{
				if(%isNameLine)
				{
					%nameLines++;
					%nameLine[%nameLines] = %file.readLine();
					//echo("nameLine[" @ %nameLines @ "] = " @ %nameLine[%nameLines]);
					
					//set isNameLine to 0 for the next line
					%isNameLine = 0;
				}
				else
				{
					//for echo purposes only. this can be removed.
					%dateLine = %file.readLine();
					//echo("dateLine = " @ %dateLine);
					
					//set isNameLine to 1 for the next line
					%isNameLine = 1;
				}
			}
			//%oldName = getSubStr(%nameLine[%namelines],20,99);
			%oldName = %nameLine[%namelines]; //temporary until dates are re-added
			//echo("nameline" @ %namelines @ " text: " @ %nameLine[%namelines]);
			
			
			
			%file.close();
			//echo("Using the existing file for this ID");
			//echo("old name: " @ %oldName);
		}
		else
		{ 
			//echo("Creating a new file for this ID");
			%newfile = 1;
		} 
		
		//more name logging stuff
		//echo("*****EXPORTING NAME*****");
		
		%file.openForAppend("config/client/logs/idlog/names/" @ %id @ ".log");
		%newname = $IDLogger::NameChange[ %i @ "num1" ];
		
		//echo("Name ID: " @ %i @ "; Name changes: " @ $IDLogger::NameChanges[%i] @ "");
		//echo("for(%j = 1; %j <= " @ $IDLogger::NameChanges[%i] @ "; %j++)");
		for(%j = 1; %j <= $IDLogger::NameChanges[%i]; %j++)
		{
			//echo("%j = " @ %j);
			if(%oldname $= %newname && %j == 1)
			{
				//echo("First name is the same as the last name in the file. Skipping!");
				
				if($IDLogger::FirstNameStopper)
				{
					error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!LOOP - This needs to be fixed");
					break;
				}
				
				$IDLogger::FirstNameStopper = 1; //fixed: this was set BEFORE checking if($IDLogger:FirstNameStopper)
			}
			else
			{
				%writename = $IDLogger::NameChange[ %i @ "num" @ %j ];
				//echo("WRITE NAME: $IDLogger::NameChange" @ %i @ "num" @ %j @ " = " @ %writename);
				
				%writedate = $IDLogger::NameChangeDate[ %i @ "num" @ %j ];
				//echo("WRITE DATE: $IDLogger::NameChangeDate" @ %i @ "num" @ %j @ " = " @ %writedate);
				
				$IDLogger::NamesExported++;
				%file.writeLine(%writedate); // Use NL instead of calling writeLine multiple times?
				%file.writeLine(%writename);
				//echo(%writedate @ " *newline* " @ %writename);
			}
		}
		$IDLogger::FirstNameStopper = 0;
		
		%file.close();
		
		// end of name logging stuff
		
		%file.openForWrite("config/client/logs/idlog/ids/" @ %ID @ ".log");
		%file.writeLine(%Name); // Use NL instead of calling writeLine multiple times?
		%file.writeLine("Last seen: " @ %Seen);
		%file.close();
		//echo("--------------------------------------------------");
	}
	
	// Always echo this
	echo($IDLogger::IDsExported SPC "IDs exported;" SPC $IDLogger::NamesExported SPC "names exported");
	if($IDLogger::ManualIDs)
	{
		echo($IDLogger::ManualIDs SPC "IDs rejected");
	}
	
	%file.delete();
	deleteVariables("$IDLogger::*"); // Once everything is exported, we need to clear it
	IDLogger_Init();
}

// This function will return the total number of name changes logged. Note: Session IDs are not counted.
// echo("Average: " @ IDLogger_getTotalNameChanges()/getFileCount("config/client/logs/idlog/names/*"));
function IDLogger_getTotalNameChanges()
{
	%count = getFileCount("config/client/logs/idlog/names/*");
	%file = new fileobject();
	
	for(%i = 1; %i <= %count; %i++)
	{
		if(%i == 1)
			%currentFile = findFirstFile("config/client/logs/idlog/names/*");
		else
			%currentFile = findNextFile("config/client/logs/idlog/names/*");
		
		%file.openForRead(%currentFile);
		
		%isNameLine = 0; // IMPORTANT: First line is a date.
		while(!%file.isEOF())
		{
			if(%isNameLine)
			{
				%nameLines++;
				%nameLine[%nameLines] = %file.readLine();
				
				//set isNameLine to 0 for the next line
				%isNameLine = 0;
			}
			else
			{
				//for echo purposes only. this can be removed.
				%dateLine = %file.readLine();
				
				//set isNameLine to 1 for the next line
				%isNameLine = 1;
			}
		}
	}
	
	%file.delete();
	return %nameLines;
}

function IDLogger_ImportCakeLog(%file) // broken, don't use
{
	echo("Importing CakeLog file...");
	IDLogger_Export();
	exec(%file);
	echo("Last Modified: " @ $IDLogList_LastModified @ "; Highest ID:" @ $CakeID::HighestKnownID @ "; Total Captures: " @ $CakeID::TotalCaptures @ "; TOTAL IDS TO IMPORT: " @ $CakeID::TotalIDs);
	
	for(%i = 1; %i <= $CakeID::TotalIDs; %i++)
	{
		IDLogger_LogID($CakeID::Name[%i],$CakeID::ID[%i],$CakeID::LastSeen[%i]);
	}
	
	deleteVariables("$CakeID::*");
	deleteVariables("$IDLogList_LastModified*");
	
	IDLogger_Export();
	
	echo("/////////////////////FINISHED IMPORTING CAKELOG/////////////////////");
}

IDLogger_Init();