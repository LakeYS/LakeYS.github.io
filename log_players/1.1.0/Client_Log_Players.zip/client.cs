$IDLoggerPref::DisableEcho = 0;
$IDLoggerPref::NoExport = 0;

package IDLogger
{
	function secureClientCmd_ClientJoin(%name,%num,%id,%a,%b,%c,%d,%e,%f)
	{
		Parent::secureClientCmd_ClientJoin(%name,%num,%id,%a,%b,%c,%d,%e,%f);
		IDLogger_PlaytimeStartID(%id);
		IDLogger_LogID(%name,%id);
	}
	
	function secureClientCmd_ClientDrop(%name,%rowID,%b,%c,%d,%e,%f,%g)
	{
		// I would use the FindSessionIDByName function, but that would screw things up if there's multiple ids with the same name (it can happen if someone changes their name and the old name is taken)
		%text = NPL_List.getRowTextById(%rowID);
		%id = getWord(%text,3+getWordCount(%text)-7); // Is there a better way to do this?
		IDLogger_PlaytimeEndID(%id);
		Parent::secureClientCmd_ClientDrop(%name,%rowID,%a,%b,%c,%d,%e,%f,%g);
	}
	
	function disconnect(%a)
	{
		%total = $IDLoggerTime::ClientCountTotal;
		for(%i = 1; %i <= %total; %i++)
		{
			%id = $IDLoggerTime::ClientCountID[%i];
			
			$IDLoggerTime::ClientCount[%id] = 1; // We're clearing everything, so we should clear their client count.
			IDLogger_PlaytimeEndID(%id);
		}
		
		if(!$IDLoggerPref::NoExport)
		{
			echo("Exporting ID log");
			%file = new FileObject();
			%file.openForWrite("config/client/logs/idlog/HighestID.log");
			%file.writeLine($IDLogger::HighestID);
			%file.close();
			
			for(%i = 1; %i <= $IDLogger::TotalSessionIDs; %i++)
			{
				$IDLogger::IDsExported++;
				$IDLogger::IDsExportedTotal++;
			
				%ID = $IDLogger::ID[%i];
				%Name = $IDLogger::Name[%i];
				%Seen = $IDLogger::Seen[%i];
				
				%file.openForRead("config/client/logs/idlog/ids/" @ %ID @ ".log");
				%linesRead = 0;
				while(!%file.isEOF() && %linesRead < 3)
				{
					%line = %file.readLine();
					%linesRead++;
					
					//echo("line" @ %linesRead @ " = " @ %line);
					
					if(%linesRead == 3 && getWord(%line,0) $= "Playtime:") //Playtime
						%playtimeFile = getWord(%line,1);
				}
				%file.close();
				
				//echo("Read playtime from file: " @ %playtimeFile);
				%Playtime = $IDLogger::Playtime[%id]+%playtimeFile; // Add playtime from file to current playtime
				
				//echo("Added file to total: " @ %playtimeFile @ " + " @ $IDLogger::Playtime[%id] @ " = " @ %Playtime);
				
				//echo("ID=" @ %ID SPC "Name=" @ %Name SPC "Seen=" @ %Seen);
				
				// NAME LOGGING
				if(isFile("config/client/logs/idlog/names/" @ %id @ ".log")) 
				{
					%file.openForRead("config/client/logs/idlog/names/" @ %id @ ".log");
					
					%isNameLine = 0; // IMPORTANT: First line is a date.
					while(!%file.isEOF())
					{
						if(%isNameLine)
						{
							%nameLines++;
							%nameLine[%nameLines] = %file.readLine();
							
							//set isNameLine to 0 for the next line
							%isNameLine = 0;
						}
						else
						{
							//set isNameLine to 1 for the next line
							%isNameLine = 1;
						}
					}
					//%oldName = getSubStr(%nameLine[%namelines],20,99);
					%oldName = %nameLine[%namelines];
					%file.close();
				}
				else
				{
					%newfile = 1;
				} 
				
				//more name logging stuff
				%file.openForAppend("config/client/logs/idlog/names/" @ %id @ ".log");
				%newname = $IDLogger::NameChange[ %i @ "num1" ];
				
				for(%j = 1; %j <= $IDLogger::NameChanges[%i]; %j++)
				{
					//echo("%j = " @ %j);
					if(%oldname $= %newname && %j == 1)
					{
						
						if($IDLogger::FirstNameStopper)
						{
							error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!LOOP - This needs to be fixed");
							break;
						}
						
						$IDLogger::FirstNameStopper = 1; //fixed: this was set BEFORE checking if($IDLogger:FirstNameStopper)
					}
					else
					{
						%writename = $IDLogger::NameChange[ %i @ "num" @ %j ];
						
						%writedate = $IDLogger::NameChangeDate[ %i @ "num" @ %j ];
						
						$IDLogger::NamesExported++;
						%file.writeLine(%writedate);
						%file.writeLine(%writename);
					}
				}
				$IDLogger::FirstNameStopper = 0;
				
				%file.close();
				
				// end of name logging stuff
				
				%file.openForWrite("config/client/logs/idlog/ids/" @ %ID @ ".log");
				%file.writeLine(%Name);
				%file.writeLine("Last seen: " @ %Seen);
				%file.writeLine("Playtime: " @ %Playtime); 
				%file.close();
			}
			
			// Always echo this
			echo($IDLogger::IDsExported SPC "IDs exported;" SPC $IDLogger::NamesExported SPC "names exported");
			if($IDLogger::ManualIDs)
			{
				echo($IDLogger::ManualIDs SPC "IDs rejected");
			}
			
			%file.delete();
			deleteVariables("$IDLogger::*"); // Once everything is exported, we need to clear it
			deleteVariables("$IDLoggerTime::*");
			
			IDLogger_Init();
		}
		
		Parent::disconnect(%a);
	}
};

if($IDLogger)
	deactivatePackage("IDLogger");

activatePackage("IDLogger");
$IDLogger = 1;

function IDLogger_Init()
{
	if($IDLogger::TotalSessionIDs $= "")
		$IDLogger::TotalSessionIDs = 0;
	
	%file = new fileobject();
	
	if(isFile("config/client/logs/idlog/HighestID.log"))
	{
		%file.openForRead("config/client/logs/idlog/HighestID.log");
		$IDLogger::HighestID = %file.readline();
		echo("The highest logged ID is" SPC $IDLogger::HighestID @ "!");
		%file.close();
	}
	else
	{
		warn("No highest ID file, setting to 0...");
		$IDLogger::HighestID = 0;
	}
	
	if(isFile("config/client/idlog/HighestID.log") || getFileCount("config/client/idlog/ids/*") > 0) // Because everything was moved from config/idlog to config/logs/idlog
		error("There are files in the old idlog folder. Please move these to the new folder (config/client/logs/idlog)");
	
	%file.delete();
}

// This can be moved. We don't need to re-call it on re-initialize, the reset clients function should handle that. Just fix the variables so they aren't cleared after an export and it should be nearly good to go. (Or good to spend hours testing and fixing to be good to do)
function IDLogger_PlaytimeStartID(%id)
{
	if($IDLoggerTime::Start[%id]) // If there's already a start time, we're dealing with multiple clients
	{
		$IDLoggerTime::ClientCount[%id]++; // Keep count of their clients so we know when all of them have disconnected.
		
		if(!$IDLoggerPref::DisableEcho)
			warn("ID Logger - Duplicate client (" @ $IDLoggerTime::ClientCount[%id] @ " total), ignoring...");
	}
	else
	{
		$IDLoggerTime::ClientCount[%id] = 1; // Initialize the client count as 1.
		$IDLoggerTime::Start[%id] = mFloatLength(getRealTime()/1000,0); // Time in seconds
		
		$IDLoggerTime::ClientCountTotal++; // Client count total does not include duplicates.
		$IDLoggerTime::ClientCountID[$IDLoggerTime::ClientCountTotal] = %id;
		
		//echo("Set start time for " @ %id @ " to " @ $IDLoggerTime::Start[%id] @ ". Total client count:" SPC $IDLoggerTime::ClientCountTotal);
	}
}

function IDLogger_PlaytimeEndID(%id)
{
	$IDLoggerTime::ClientCountTotal--;
	
	if(!$IDLogger::SessionID[%id]) // If there's no session ID, we'll need to re-assign a session ID so this 
	{
		$IDLogger::TotalSessionIDs++;
		%SessionID = $IDLogger::TotalSessionIDs;
		$IDLogger::SessionID[%id] = %SessionID;
		
		$IDLogger::ID[%SessionID] = %id;
	}
	
	//echo("ending id " @ %id @ " with a client count of " @ $IDLoggerTime::ClientCount[%id]);
	$IDLoggerTime::ClientCount[%id]--;
	if($IDLoggerTime::ClientCount[%id] > 0)
	{
		if(!$IDLoggerPref::DisableEcho)
			warn("ID Logger - Duplicate client disconnected, ignoring...");
		
		return;
	}
	
	%realTime = mFloatLength(getRealTime()/1000,0);
	
	//%echoOldPlaytime = $IDLogger::Playtime[%id];
	$IDLogger::Playtime[%id] = $IDLogger::Playtime[%id]+(%realTime - $IDLoggerTime::Start[%id]); // Add playtime to their current session amount
	//echo("realTime - timeStart: " @ %realTime @ " - " @ $IDLoggerTime::Start[%id] @ " = " @ $IDLogger::Playtime[%id]);
	//echo(%id @ " prevPlaytime + newPlaytime: " @ %echoOldPlaytime @ " + " @ %realTime - $IDLoggerTime::Start[%id] @ " = " @ $IDLogger::Playtime[%id]);
	$IDLoggerTime::Start[%id] = 0; // Clear their start time
	
	//echo("Ended ID " @ %id @ ", total playtime is " @ $IDLogger::Playtime[%id]);
	
	return %playtime; //Replace this with the code to export playtime or something (Maybe move this code to the LogID function?)
}

//IDLogger_LogID(Name, BLID, Date)
//If a date is specified, the ID is treated as a "Manual Entry" and will be ignored if it already exists.
//Playtime also won't be logged if a date is specified.
function IDLogger_LogID(%name,%id,%date)
{
	if(!$IDLoggerPref::DisableEcho)
	{
		echo("ID Logger - Registering name \"" @ %name @ "\" to id " @ %id);
	}
	
	if(%date && isFile("config/client/logs/idlog/ids/" @ %id @ ".log"))
	{
		warn("ID Logger - Manual entry ID already exists, ignoring...");
		$IDLogger::ManualIDs++;
		return;
	}
	
	if(%id == 999999)
		return;
	
	if(%id >= 400000) //if ids actually get this high i guess i'll just have to update
	{
		warn("ID Logger - ID " @ %id @ " is above 400k, ignoring...");
		return;
	}
	
	if(%id < 0) //if a mysterious broken id is found
	{
		warn("ID Logger - ID " @ %id @ " is < 0, ignoring...");
		return;
	}
	
	if(!$IDLogger::SessionID[%id])
	{
		//echo("This is a new session ID!");
		
		$IDLogger::TotalSessionIDs++;
		%SessionID = $IDLogger::TotalSessionIDs;
		$IDLogger::SessionID[%id] = %SessionID;
		
		// NAME COUNT
		$IDLogger::NameChanges[%SessionID]++;
		
		// NAME
		$IDLogger::NameChange[ %SessionID @ "num" @ $IDLogger::NameChanges[%SessionID] ] = %name; //$IDLogger::NameChange[SessID]num[Count]
		
		// NAME DATE
		$IDLogger::NameChangeDate[ %SessionID @ "num" @ $IDLogger::NameChanges[%SessionID] ] = getDateTime(); //$IDLogger::NameChangeDate[SessID]num[Count]
	}
	else
	{
		//echo("This is an existing session ID!");
		%SessionID = $IDLogger::SessionID[%id]; 
		
		//name logging stuff
		%oldname = $IDLogger::NameChange[ %SessionID @ "num" @ $IDLogger::NameChanges[%SessionID] ];
		//echo("Old name: " @ %oldname);
		if(%name !$= %oldname)
		{
			//echo("New name " @ $IDLogger::NameChanges[%SessionID]+1 @ "! (" @ %oldname @ " !$= " @ %name @ ")");
			$IDLogger::NameChanges[%SessionID]++;
			
			// NAME
			$IDLogger::NameChange[ %SessionID @ "num" @ $IDLogger::NameChanges[%SessionID] ] = %name; //$IDLogger::NameChange[SessID]num[Count]
			
			// NAME DATE
			$IDLogger::NameChangeDate[ %SessionID @ "num" @ $IDLogger::NameChanges[%SessionID] ] = getDateTime(); //$IDLogger::NameChangeDate[SessID]num[Count]
			//echo("Setting $IDLogger::NameChangeDate[" @ %sessionID @ "]num[" @ $IDLogger::NameChanges[%sessionID] @ "] to " @ getDateTime());
		}
	}
	
	if(%id > $IDLogger::HighestID)
	{
		if(!$IDLoggerPref::DisableEcho)
		{
			echo("Highest ID updated! (" @ %id @ " > " @ $IDLogger::HighestID @ ")");
		}
		$IDLogger::HighestID = %id;
	}
	
	$IDLogger::Name[%SessionID] = %name;
	$IDLogger::ID[%SessionID] = %id;
	
	if(!%date)
	{
		$IDLogger::Seen[%SessionID] = getDateTime();
	}
	else
	{
		//echo("Using manual date for this ID (" @ %date @ ")");
		$IDLogger::Seen[%SessionID] = %date;
		//set this up with playtime logging too
	}
	
	$IDLogger::GetBLID[%SessionID] = %id;
	$IDLogger::GetNameByBLID[%id] = %name;
}

// This function will return the session IDs with a name that matches or contains the text in %name. (Note: %name is not case-sensitive)
// Set %exact to 1 if you only want names that are an exact match.
// %returnCount is the number of IDs you want to return (0 to return all of them)
function IDLogger_FindSessionIDByName(%name,%exact,%returnCount)
{
	%name = strupr(%name);
	for(%i = 1; %i <= $IDLogger::TotalSessionIDs; %i++)
	{
		%returnThis = 0;
		if(%exact)
		{
			if(strupr($IDLogger::Name[%i]) $= %name)
				%returnThis = 1;
		}
		else
		{
			if(strstr(strupr($IDLogger::Name[%i]),%name) >= 0)
				%returnThis = 1;
		}
		
		if(%returnThis)
		{
			if(%return $= "") // Avoid a blank space at the beginning
				%return = %i;
			else
				%return = %return SPC %i;
		}
			
		if(%returnCount > 0 && getWordCount(%return) >= %returnCount)
			break;
	}
	return %return;
}

// This function will return the total number of name changes logged. Note: Session IDs are not counted.
// echo("Average: " @ IDLogger_getTotalNameChanges()/getFileCount("config/client/logs/idlog/names/*"));
function IDLogger_getTotalNameChanges()
{
	%count = getFileCount("config/client/logs/idlog/names/*");
	%file = new fileobject();
	
	for(%i = 1; %i <= %count; %i++)
	{
		if(%i == 1)
			%currentFile = findFirstFile("config/client/logs/idlog/names/*");
		else
			%currentFile = findNextFile("config/client/logs/idlog/names/*");
		
		%file.openForRead(%currentFile);
		
		%isNameLine = 0; // IMPORTANT: First line is a date.
		while(!%file.isEOF())
		{
			if(%isNameLine)
			{
				%nameLines++;
				%nameLine[%nameLines] = %file.readLine();
				
				//set isNameLine to 0 for the next line
				%isNameLine = 0;
			}
			else
			{
				//set isNameLine to 1 for the next line
				%isNameLine = 1;
			}
		}
	}
	
	%file.delete();
	return %nameLines;
}

function IDLogger_ImportCakeLog(%file) // broken, don't use
{
	echo("Importing CakeLog file...");
	IDLogger_Export();
	exec(%file);
	echo("Last Modified: " @ $IDLogList_LastModified @ "; Highest ID:" @ $CakeID::HighestKnownID @ "; Total Captures: " @ $CakeID::TotalCaptures @ "; TOTAL IDS TO IMPORT: " @ $CakeID::TotalIDs);
	
	for(%i = 1; %i <= $CakeID::TotalIDs; %i++)
	{
		IDLogger_LogID($CakeID::Name[%i],$CakeID::ID[%i],$CakeID::LastSeen[%i]);
	}
	
	deleteVariables("$CakeID::*");
	deleteVariables("$IDLogList_LastModified*");
	
	IDLogger_Export();
	
	echo("/////////////////////FINISHED IMPORTING CAKELOG/////////////////////");
}

IDLogger_Init();