%date = getDateTime();

exec("./ui/shrineGui.cs");

if(getRandom(1,6666) == 1)
  exec("./ui/ui.cs");
