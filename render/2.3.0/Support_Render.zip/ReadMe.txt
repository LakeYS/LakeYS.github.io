If packaging this add-on in a game-mode with Slayer, be sure to place GameMode_Slayer ABOVE Support_Render in the list.

The full source code and changelogs for this add-on can be found at these links:
https://github.com/LakeYS/blockland-render
https://gitlab.com/LakeYS/blockland-render
